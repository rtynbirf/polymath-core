## Summary

Внешние утверждения о разметчиках RLHF приведены к канону принципа 6 Манифеста: 7 заявлений → 4 статуса (ПОДТВЕРЖДЕНО / ЧАСТИЧНО / ОПРОВЕРГНУТО / НЕДОКАЗАНО), 20+ источников с URL, десятиминутный ручной чек-лист. Хаб — `docs/RLHF_DOSSIER.md`, самодостаточные артефакты — `docs/dossier/` (HTML, PDF, SHA-256 манифест). Docs-only: runtime не затронут, issues не закрывает.

## Type

- [x] `docs` — только документация

## Breaking changes

None

## Verification

Локальный прогон на HEAD ветки:

```bash
python3 scripts/check.py
# Result: 26 passed, 0 failed (of 26 claims)
# All claims verified. Repo is reproducible.
```

- [x] `make verify` exit 0 (26/26 checks pass — актуальный канон v3.20+; «12/12» в шаблоне устарел)
- [x] Новый claim в `README.md` не добавляется — чек не требуется; целостность артефактов верифицируется `docs/dossier/manifest_sha256.txt` (`sha256sum -c`)
- [x] Архитектуру не меняет — ADR не требуется (CONTRIBUTING.md: ADR только для архитектуры)

## Checklist

- [x] Commit message следует [Conventional Commits](https://www.conventionalcommits.org) (`docs(dossier): ...`, `docs(changelog): ...`)
- [x] PR title = commit message (verified by `amannn/action-semantic-pull-request`)
- [x] `Signed-off-by` в коммите (DCO, `git commit -s`) — подпись в коммите `docs(changelog)`, при squash-merge дублируется в итоговое сообщение
- [x] Нет секретов в diff (pre-commit hook `gitleaks`; скан паттернов PAT/токенов чист, `check.py` #23 token hygiene — PASS)
- [x] `CHANGELOG.md` обновлён в секции `[Unreleased]` (Keep a Changelog) — коммит `docs(changelog)`
- [x] Новый workflow / action не добавляется — пункт про CODEOWNERS и Dependabot grouping не применим
- [x] Self-review пройден; язык: документ на русском, коммиты на английском — как в окружающих файлах
