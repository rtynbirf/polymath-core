@echo off
chcp 65001 >nul
setlocal EnableExtensions
title POLIMAT FINISH - local squash to main (no gh, no browser)

rem ============================================================================
rem  Финиш без gh и без браузера - для машин, где GitHub CLI не установлен.
rem  Делает то же, что squash-merge на GitHub, но локально чистым git:
rem   * берёт свежий main с GitHub
rem   * squash-вливает ветку feat/docs-rlhf-dossier в ОДИН коммит
rem   * сообщение коммита - каноническое, с Signed-off-by (DCO)
rem   * пушит main на GitHub
rem   * удаляет ветку фичи - PR #14 закроется автоматически
rem  Идемпотентно: повторный запуск ничего не задвоит.
rem  Нужно: папка polymath-os рядом (её создал POLIMAT_AUTO_PUSH.bat)
rem         + POLIMAT_COMMIT_MSG.txt в той же папке, где и сам батник.
rem ============================================================================

set "BRANCH=feat/docs-rlhf-dossier"
set "COMMIT_MSG=POLIMAT_COMMIT_MSG.txt"
set "GITID=-c user.name=rtynbirf -c user.email=rtynbirf@users.noreply.github.com"

cd /d "%~dp0"
if not exist "polymath-os\.git" (
  echo [ОШИБКА] Нет папки polymath-os рядом с батником.
  echo Сначала запусти POLIMAT_AUTO_PUSH.bat - он создаст клон и зальёт ветку.
  pause
  exit /b 1
)
if not exist "%COMMIT_MSG%" (
  echo [ОШИБКА] Не найден %COMMIT_MSG% рядом с батником.
  echo Скачай свежий POLIMAT_PACK_v3.zip и распакуй с заменой.
  pause
  exit /b 1
)

cd polymath-os
git config http.version HTTP/1.1

rem --- ремонт состояния: мусор прерванного am/rebase ---
if exist ".git\rebase-apply" (
  git am --abort >nul 2>nul
  if exist ".git\rebase-apply" rmdir /s /q ".git\rebase-apply"
)
if exist ".git\rebase-merge" (
  git rebase --abort >nul 2>nul
  if exist ".git\rebase-merge" rmdir /s /q ".git\rebase-merge"
)

echo [1/4] Забираю свежий main с GitHub...
git fetch origin main --quiet
if errorlevel 1 git -c http.version=HTTP/1.1 fetch origin main --quiet
if errorlevel 1 (
  echo [ОШИБКА] Не смог забрать main. Сеть? Запусти позже или пришли лог.
  cd ..
  pause
  exit /b 1
)
git checkout -f -B main origin/main --quiet
echo        main готов.

echo [2/4] Готовлю ветку %BRANCH%...
git rev-parse --verify --quiet "%BRANCH%" >nul 2>nul
if errorlevel 1 (
  git fetch origin "%BRANCH%" --quiet
  if errorlevel 1 git -c http.version=HTTP/1.1 fetch origin "%BRANCH%" --quiet
  git checkout -f -B "%BRANCH%" "origin/%BRANCH%" --quiet
)

rem --- уже влито в main? идемпотентность по содержимому ---
git cat-file -e "main:docs/RLHF_DOSSIER.md" 2>nul
if not errorlevel 1 goto already

echo [3/4] Squash-вливаю ветку в main одним коммитом...
git merge --squash "%BRANCH%"
if errorlevel 1 (
  echo [ОШИБКА] Squash не лёг. Пришли этот лог целиком - разберёмся.
  cd ..
  pause
  exit /b 1
)
git diff --cached --quiet
if errorlevel 1 (
  git %GITID% commit --quiet -F "..\%COMMIT_MSG%"
  if errorlevel 1 (
    echo [ОШИБКА] Коммит не собрался. Пришли лог.
    cd ..
    pause
    exit /b 1
  )
  for /f "delims=" %%H in ('git rev-parse --short HEAD') do echo        Коммит %%H собран.
) else (
  echo        Изменений нет - уже влито, коммит не нужен.
)

echo [4/4] Пушу main на GitHub...
git push origin main && goto pushed
ping -n 4 127.0.0.1 >nul
echo        Попытка 2/3: HTTP/1.1...
git -c http.version=HTTP/1.1 push origin main && goto pushed
ping -n 5 127.0.0.1 >nul
echo        Попытка 3/3: HTTP/1.1 + IPv4 + OpenSSL...
git -c http.version=HTTP/1.1 -c http.sslBackend=openssl push origin main --ipv4 && goto pushed
echo [ОШИБКА] Push main не прошёл 3 раза. Пришли лог - разберёмся.
cd ..
pause
exit /b 1
:pushed
echo        main на GitHub.

rem --- удаляю ветку фичи: PR закроется сам ---
git push origin --delete "%BRANCH%" >nul 2>nul
if errorlevel 1 (
  echo        Ветка уже удалена или не существует - не страшно.
) else (
  echo        Ветка %BRANCH% удалена - PR #14 закроется автоматически.
)
goto done

:already
echo        docs/RLHF_DOSSIER.md уже в main - вливать нечего. Убираю ветку...
git push origin --delete "%BRANCH%" >nul 2>nul
goto done

:done
echo.
for /f "delims=" %%L in ('git log --oneline -2') do echo   %%L
cd ..
echo.
echo ==========================================================================
echo  ГОТОВО - теперь по-настоящему: docs/RLHF_DOSSIER.md в main на GitHub.
echo  Учти честно: PR #14 закроется со статусом Closed, без бейджа Merged -
echo  содержимое main при этом идентично squash-merge по канону.
echo ==========================================================================
pause
endlocal
