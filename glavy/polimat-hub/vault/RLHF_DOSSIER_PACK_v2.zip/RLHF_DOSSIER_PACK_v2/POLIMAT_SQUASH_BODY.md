RLHF annotator evidence pack: 7 claims -> 4 statuses (VERIFIED / PARTIAL / REFUTED / UNPROVEN), 20+ verified sources with URLs, 10-minute manual checklist. Hub: docs/RLHF_DOSSIER.md + self-contained docs/dossier/ (HTML, PDF, SHA-256 manifest). Docs-only: no runtime change, make verify 26/26. CHANGELOG [Unreleased] updated.

Signed-off-by: rtynbirf <rtynbirf@users.noreply.github.com>
