RLHF DOSSIER PACK v2 — досье «RLHF и люди-разметчики: досье доказательств»
+ механизм POLIMAT (батники + патчи), канон POLIMAT_AUTO_PUSH v3.
Источник: rtynbirf/polymath-os, ветка main, squash-коммит 24e7665 (2026-11-05),
PR #14 (закрыт по FINISH-канону: содержимое долито локальным squash-ом в main).

ОДИН КЛИК — НАЖАЛ И ВСЁ
  1. Распакуй zip ЦЕЛИКОМ: правый клик по архиву — «Извлечь всё...».
  2. Двойной клик по DOSSIER_GO.bat.
  Батник сам: проверит комплектность, сверит SHA-256 каждого файла с
  манифестом (certutil), откроет доказательства в браузере и досье в
  блокноте и напишет «ГОТОВО». Вводить ничего не надо, сеть и токены
  не нужны. Запуск из окна архива не выйдет — батник сам скажет
  распаковать целиком.

ЧТО ВНУТРИ

  ОДНА КНОПКА:
  DOSSIER_GO.bat                    — нажал и готово: проверка + открытие.

  МЕХАНИЗМ (восстановление/перенос в репо; сейчас досье уже в main, так что
  это запасной путь — на будущее, если main потеряет досье):
  POLIMAT_AUTO_PUSH.bat             — полный автопилот: клон polymath-os ->
                                      патч досье (git am) -> CHANGELOG-коммит
                                      с DCO -> verify (scripts/check.py) -> пуш
                                      ветки -> PR по шаблону триажа; merge —
                                      по явной команде:
                                        POLIMAT_AUTO_PUSH.bat merge
  POLIMAT_MERGE.bat                 — один клик до конца: сам выбирает путь
                                      (gh есть -> squash-merge по канону;
                                       gh нет -> POLIMAT_FINISH.bat).
  POLIMAT_FINISH.bat                — локальный squash чистым git, без gh
                                      и без браузера (PR закроется как Closed).
  polymath-os_RLHF_DOSSIER.patch    — сам патч досье (готовый коммит, git am)
  POLIMAT_CHANGELOG.patch           — CHANGELOG-коммит со Signed-off-by (DCO)
  POLIMAT_PR_BODY.md / _MIN.md      — тело PR (полное / без CHANGELOG)
  POLIMAT_SQUASH_BODY.md            — тело squash-коммита
  POLIMAT_COMMIT_MSG.txt            — сообщение squash-коммита с DCO

  АРТЕФАКТЫ (сами документы):
  docs\RLHF_DOSSIER.md                    — хаб досье (canon format, 106 строк):
                                            7 утверждений -> 4 статуса
                                            (ПОДТВЕРЖДЕНО / ЧАСТИЧНО /
                                            ОПРОВЕРГНУТО / НЕДОКАЗАНО),
                                            20+ источников с URL,
                                            10-минутная ручная проверка.
  docs\dossier\RLHF_DOSSIER_PROOFS.html   — самодостаточный HTML (без сети)
  docs\dossier\RLHF_DOSSIER_PROOFS.pdf    — PDF (194 635 байт)
  docs\dossier\manifest_sha256.txt        — манифест целостности SHA-256

ФАЙЛЫ docs\ ВЗЯТЫ БАЙТ-В-БАЙТ из main на GitHub (git cat-file по блобам),
батники и патчи — оригиналы из гуглдрайв-пака POLIMAT, не пересобраны.

ПРОВЕРКА ЦЕЛОСТНОСТИ ВРУЧНУЮ (если хочешь без батника)
  Windows (cmd):
    certutil -hashfile docs\dossier\RLHF_DOSSIER_PROOFS.html SHA256
    certutil -hashfile docs\dossier\RLHF_DOSSIER_PROOFS.pdf SHA256
  Linux/macOS:
    sha256sum docs/dossier/RLHF_DOSSIER_PROOFS.html docs/dossier/RLHF_DOSSIER_PROOFS.pdf
  Сверь вывод с docs\dossier\manifest_sha256.txt.
  Эталон на 2026-11-07:
    HTML 19275354d0de3f76fa0a2672ba8cb072533e5f98abcb41e99a4ef9f35e5126d3
    PDF  f55bdd1479f62967a1308bae1587f460d1bc7e55de7d695bef2453d3f819165c

МЕХАНИЗМ ВОССТАНОВЛЕНИЯ (POLIMAT_AUTO_PUSH.bat), если понадобится
  1. Файлы пака держи вместе (батники, патчи и docs).
  2. Запусти POLIMAT_AUTO_PUSH.bat двойным кликом.
  3. Сейчас он честно скажет: «Пак уже влито в main — интеграция завершена»
     и ничего не задвоит (идемпотентность по содержимому).
  4. Если main потеряет досье — батник заново соберёт ветку, зальёт патч,
     откроет PR и (по команде merge) дольёт по канону; перезапуск
     продолжает с того же места.

СТАТУС В РЕПО
  Досье уже влито в main polymath-os (повторный пуш патча не нужен —
  аддитивность §1.2, дублей не делаем). CHANGELOG [Unreleased] содержит
  запись docs(dossier). Ветка feat/docs-rlhf-dossier удалена после FINISH.
