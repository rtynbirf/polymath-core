@echo off
chcp 65001 >nul
setlocal EnableExtensions
title POLIMAT AUTO PUSH v3 - RLHF dossier to polymath-os

rem ============================================================================
rem  v3 — самолечение и полный автопилот. Что нового против v2:
rem   * чистит мусор прерванного git am ("previous rebase directory still exists")
rem   * не применяет патчи повторно: смотрит на содержимое, а не на историю запусков
rem   * сам доносит CHANGELOG-коммит с Signed-off-by (DCO)
rem   * сам заполняет тело PR по шаблону триажа через gh pr edit
rem   * режим merge: POLIMAT_AUTO_PUSH.bat merge -> squash-merge по канону (24 ч)
rem  Нужно: этот батник + polymath-os_RLHF_DOSSIER.patch + POLIMAT_CHANGELOG.patch
rem         + POLIMAT_PR_BODY.md + POLIMAT_PR_BODY_MIN.md + POLIMAT_SQUASH_BODY.md
rem  Токены, пароли и ввод данных не нужны: push и gh работают через твою сессию.
rem  Прогресс сохраняется между запусками: любой перезапуск продолжит с того же места.
rem ============================================================================

set "REPO_URL=https://github.com/rtynbirf/polymath-os.git"
set "BRANCH=feat/docs-rlhf-dossier"
set "PATCH_DOSSIER=polymath-os_RLHF_DOSSIER.patch"
set "PATCH_CHANGELOG=POLIMAT_CHANGELOG.patch"
set "BODY_FULL=POLIMAT_PR_BODY.md"
set "BODY_MIN=POLIMAT_PR_BODY_MIN.md"
set "SQUASH_BODY=POLIMAT_SQUASH_BODY.md"
set "GITID=-c user.name=rtynbirf -c user.email=rtynbirf@users.noreply.github.com"

cd /d "%~dp0"

rem --- [1/6] файлы пака рядом ---
if not exist "%PATCH_DOSSIER%" (
  echo [ОШИБКА] Не найден %PATCH_DOSSIER% рядом с батником.
  echo Скачай патч из чата и положи в эту же папку, затем запусти снова.
  pause
  exit /b 1
)
echo [1/6] Патч досье на месте: %PATCH_DOSSIER%
if not exist "%PATCH_CHANGELOG%" echo        [внимание] %PATCH_CHANGELOG% не найден — CHANGELOG-коммит будет пропущен.
if not exist "%BODY_FULL%" echo        [внимание] %BODY_FULL% не найден — тело PR заполняться не будет.

rem --- [2/6] git ---
where git >nul 2>nul
if errorlevel 1 (
  echo [ОШИБКА] Git не установлен. Открываю страницу установки...
  start https://git-scm.com/download/win
  echo Установи Git for Windows ^(все галочки по умолчанию^) и запусти батник ещё раз.
  pause
  exit /b 1
)
echo [2/6] Git найден.

rem --- [3/6] клон: лестница попыток — сбросы TLS лечатся транспортом и ретраями ---
if exist "polymath-os\.git" goto clone_exists

echo [3/6] Клонирую rtynbirf/polymath-os. Попытка 1/5: стандартный shallow...
git clone --depth 1 --quiet "%REPO_URL%" && goto clone_done
ping -n 4 127.0.0.1 >nul
echo        Попытка 2/5: HTTP/1.1 — лечит обрывы на HTTP/2...
git -c http.version=HTTP/1.1 clone --depth 1 --quiet "%REPO_URL%" && goto clone_done
ping -n 4 127.0.0.1 >nul
echo        Попытка 3/5: HTTP/1.1 + IPv4 — лечит битый IPv6-маршрут...
git -c http.version=HTTP/1.1 clone --depth 1 --quiet --ipv4 "%REPO_URL%" && goto clone_done
ping -n 4 127.0.0.1 >nul
echo        Попытка 4/5: HTTP/1.1 + IPv4 + OpenSSL вместо schannel...
git -c http.version=HTTP/1.1 -c http.sslBackend=openssl clone --depth 1 --quiet --ipv4 "%REPO_URL%" && goto clone_done
ping -n 6 127.0.0.1 >nul
echo        Попытка 5/5: стандартный транспорт, последний шанс...
git clone --depth 1 --quiet "%REPO_URL%" && goto clone_done

echo.
echo [ДИАГНОСТИКА] git-транспорт не прошёл 5 раз. Проверяю доступность GitHub
echo через PowerShell — отличаю "режется только git" от "недоступен целиком"...
powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -Uri 'https://github.com/rtynbirf/polymath-os' -UseBasicParsing -TimeoutSec 20 | Out-Null; exit 0 } catch { exit 1 }"
if errorlevel 1 (
  echo GitHub недоступен из твоей сети целиком. Сбросы TLS у провайдеров часто
  echo временные: запусти батник позже, через другую сеть или через VPN.
) else (
  echo Сайт GitHub отвечает, но git-транспорт режется — это фильтр провайдера.
  echo Обычно помогает повтор позже или VPN. Прогресс сохранён:
  echo при следующем запуске продолжится с этого места.
  start https://www.githubstatus.com
)
pause
exit /b 1

:clone_exists
echo [3/6] Клон уже есть — продолжаю с того же места...
git -C polymath-os -c http.version=HTTP/1.1 pull --ff-only --quiet 2>nul
:clone_done
echo        Клон готов.

rem --- [4/6] ремонт состояния + коммиты (идемпотентно) ---
cd polymath-os
git config http.version HTTP/1.1

rem (a) мусор от прерванного git am — именно он давал fatal "previous rebase directory"
if exist ".git\rebase-apply" (
  git am --abort >nul 2>nul
  if exist ".git\rebase-apply" rmdir /s /q ".git\rebase-apply"
  echo        Очистил следы прерванного git am.
)
if exist ".git\rebase-merge" (
  git rebase --abort >nul 2>nul
  if exist ".git\rebase-merge" rmdir /s /q ".git\rebase-merge"
  echo        Очистил следы прерванного rebase.
)

echo [4/6] Синхронизируюсь с GitHub и проверяю, что уже сделано...
git fetch origin main --quiet 2>nul
if errorlevel 1 git -c http.version=HTTP/1.1 fetch origin main --quiet 2>nul
git fetch origin "%BRANCH%" --quiet 2>nul
if errorlevel 1 git -c http.version=HTTP/1.1 fetch origin "%BRANCH%" --quiet 2>nul

rem (b) если пак уже влито в main (squash-merge) — просто доводим локаль до main
git cat-file -e "origin/main:docs/RLHF_DOSSIER.md" 2>nul
if not errorlevel 1 (
  echo        Пак уже влито в main — интеграция завершена. Синхронизирую локаль...
  git checkout main --quiet 2>nul
  git pull --ff-only --quiet 2>nul
  cd ..
  echo ГОТОВО: docs/RLHF_DOSSIER.md уже в main. Больше ничего делать не нужно.
  pause
  exit /b 0
)

rem (c) встаём на ветку: предпочитаю состояние origin, иначе локальную ветку
git rev-parse --verify --quiet "origin/%BRANCH%" >nul 2>nul
if not errorlevel 1 (
  git checkout -f -B "%BRANCH%" "origin/%BRANCH%" --quiet
  goto branch_ready
)
git rev-parse --verify --quiet "%BRANCH%" >nul 2>nul
if not errorlevel 1 (
  git checkout -f "%BRANCH%" --quiet
  goto branch_ready
)
git checkout -f -B "%BRANCH%" --quiet
:branch_ready

rem (d) коммит досье: если файл уже в ветке — повторно патч НЕ применяю
if exist "docs\RLHF_DOSSIER.md" (
  echo        Коммит досье уже в ветке — повторно не применяю.
) else (
  echo        Применяю патч досье как готовый коммит...
  git %GITID% am --keep-non-patch "..\%PATCH_DOSSIER%"
  if errorlevel 1 (
    git am --abort >nul 2>nul
    if exist ".git\rebase-apply" rmdir /s /q ".git\rebase-apply"
    echo [ОШИБКА] Патч досье не применился. Это нештатная ситуация —
    echo пришли этот вывод целиком, разберёмся.
    cd ..
    pause
    exit /b 1
  )
)

rem (e) CHANGELOG-коммит с DCO: тоже идемпотентно, по содержимому CHANGELOG.md
set "NOCHANGELOG="
findstr /C:"RLHF annotator evidence pack" CHANGELOG.md >nul 2>nul
if not errorlevel 1 (
  echo        CHANGELOG-коммит уже в ветке.
) else (
  if exist "..\%PATCH_CHANGELOG%" (
    echo        Добавляю CHANGELOG-коммит со Signed-off-by ^(DCO^)...
    git %GITID% am "..\%PATCH_CHANGELOG%"
    if errorlevel 1 (
      git am --abort >nul 2>nul
      if exist ".git\rebase-apply" rmdir /s /q ".git\rebase-apply"
      echo        [внимание] CHANGELOG-патч не лёг — продолжаю без него:
      echo        тело PR будет минимальным, две галки останутся пустыми.
      set "NOCHANGELOG=1"
    )
  ) else (
    echo        [внимание] %PATCH_CHANGELOG% не найден — продолжаю без него.
    set "NOCHANGELOG=1"
  )
)
for /f "delims=" %%H in ('git rev-parse --short HEAD') do set "COMMIT=%%H"
echo        Ветка %BRANCH% готова, HEAD %COMMIT%.

rem --- [5/6] verify по канону ---
set "PYCMD="
python --version >nul 2>nul && set "PYCMD=python"
if not defined PYCMD py --version >nul 2>nul && set "PYCMD=py"
set "VERIFY_OK=0"
if defined PYCMD (
  echo [5/6] Верификация канона: %PYCMD% scripts/check.py ^(UTF-8 mode^)...
  set "PYTHONUTF8=1"
  %PYCMD% scripts\check.py > "%TEMP%\polimat_verify.txt" 2>&1
  if not errorlevel 1 set "VERIFY_OK=1"
)
if not "%VERIFY_OK%"=="1" goto verify_soft
for /f "usebackq tokens=*" %%L in (`findstr /C:"Result:" "%TEMP%\polimat_verify.txt"`) do set "VERIFYLINE=%%L"
if not defined VERIFYLINE set "VERIFYLINE=26/26 PASS"
echo        verify: %VERIFYLINE% — канон принял пак.
goto verify_done
:verify_soft
echo        [внимание] verify локально не прошёл или Python не найден:
echo        специфика Windows ^(заглушка Python / кодировка charmap^) —
echo        CI на Linux прогонит 26/26 автоматически. Продолжаю.
:verify_done

rem --- [6/6] push с ретраями и force-страховкой ---
echo [6/6] Push в твой GitHub. Если выскочит окно браузера — это GitHub
echo        подтверждает, что ты владелец. Нажми Continue/Approve — один раз.
git push -u origin "%BRANCH%" && goto push_done
ping -n 5 127.0.0.1 >nul
echo        Push не прошёл — попытка 2/4...
git push -u origin "%BRANCH%" && goto push_done
ping -n 6 127.0.0.1 >nul
echo        Push не прошёл — попытка 3/4...
git push -u origin "%BRANCH%" && goto push_done
ping -n 6 127.0.0.1 >nul
echo        Попытка 4/4: force — безопасно: это ветка нашего PR, содержимое то же.
git push -f -u origin "%BRANCH%" && goto push_done
echo [ОШИБКА] Push не прошёл 4 раза. Если GitHub просил подтвердить сессию в
echo браузере — подтверди окно и запусти батник ещё раз: всё продолжится.
cd ..
pause
exit /b 1
:push_done
echo        Ветка %BRANCH% на GitHub.

rem --- PR: проверяю состояние, заполняю тело по шаблону триажа ---
set "PRSTATE="
gh pr view "%BRANCH%" --repo rtynbirf/polymath-os --json state --jq .state > "%TEMP%\polimat_prstate.txt" 2>nul
set /p PRSTATE=<"%TEMP%\polimat_prstate.txt"
if "%PRSTATE%"=="MERGED" (
  echo        PR уже влит — довожу локальный main до актуального...
  git checkout main --quiet 2>nul
  git pull --ff-only --quiet 2>nul
  cd ..
  echo ГОТОВО: досье уже в main канона.
  pause
  exit /b 0
)

set "GHOK=0"
where gh >nul 2>nul && gh auth status >nul 2>nul && set "GHOK=1"
if "%GHOK%"=="0" goto manual_pr

set "BODYFILE=%BODY_FULL%"
if "%NOCHANGELOG%"=="1" set "BODYFILE=%BODY_MIN%"
if not exist "..\%BODYFILE%" goto manual_pr
echo Заполняю тело PR по шаблону триажа: Summary, Type: docs, Verification, Checklist...
gh pr edit "%BRANCH%" --repo rtynbirf/polymath-os --body-file "..\%BODYFILE%" && goto pr_body_done
echo        PR ещё не существует или gh не смог — пробую создать...
gh pr create --repo rtynbirf/polymath-os --base main --head "%BRANCH%" --title "docs(dossier): add RLHF annotator evidence pack" --body-file "..\%BODYFILE%" && goto pr_body_done
echo gh не справился — открываю ручную страницу.
:manual_pr
start "" "https://github.com/rtynbirf/polymath-os/pulls"
if "%NOCHANGELOG%"=="1" (
  echo Открой наш PR, нажми Edit и вставь содержимое файла %BODY_MIN%.
) else (
  echo Открой наш PR, нажми Edit и вставь содержимое файла %BODY_FULL%.
)
goto after_pr
:pr_body_done
echo        Тело PR заполнено: галка Type docs, Summary, verify 26/26, Checklist.
:after_pr

rem --- merge по канону: только по явной команде "батник merge" ---
if /i "%~1"=="merge" goto do_merge
echo.
echo По канону PR живёт не дольше 24 часов и мержится squash-ом.
echo Когда убедишься, что PR на GitHub выглядит как надо — запусти:
echo     POLIMAT_AUTO_PUSH.bat merge
goto final

:do_merge
set "MERGED_OK=0"
echo [MERGE] Squash-merge по канону + удаление ветки...
if exist "..\%SQUASH_BODY%" (
  gh pr merge "%BRANCH%" --repo rtynbirf/polymath-os --squash --delete-branch --subject "docs(dossier): add RLHF annotator evidence pack" --body-file "..\%SQUASH_BODY%"
) else (
  gh pr merge "%BRANCH%" --repo rtynbirf/polymath-os --squash --delete-branch --subject "docs(dossier): add RLHF annotator evidence pack" --body "RLHF annotator evidence pack: 7 claims -> 4 statuses, 20+ verified sources, 10-minute checklist. Docs-only, make verify 26/26. CHANGELOG [Unreleased] updated. Signed-off-by: rtynbirf <rtynbirf@users.noreply.github.com>"
)
if errorlevel 1 (
  echo gh pr merge не прошёл.
  echo Запусти POLIMAT_FINISH.bat — он вольёт пак в main без gh и без браузера.
  goto final
)
set "MERGED_OK=1"
echo        PR влит squash-ом, ветка удалена. Синхронизирую локальный main...
git checkout main --quiet 2>nul
git pull --ff-only --quiet 2>nul
goto final

:final
for /f "delims=" %%U in ('gh pr view "%BRANCH%" --repo rtynbirf/polymath-os --json url --jq .url 2^>nul') do set "PRURL=%%U"
cd ..
echo.
echo ==========================================================================
if /i "%~1"=="merge" (
  if not "%MERGED_OK%"=="1" (
    echo  НЕ СЛИТО: слияние не состоялось — это факт, а не "готово".
    echo  Запусти POLIMAT_FINISH.bat — завершит дело чистым git, без gh.
  ) else (
    echo  ГОТОВО: пак влит в main канона. Досье теперь часть polymath-os.
  )
) else (
  echo  ГОТОВО: PR готов и заполнен по шаблону триажа.
  echo  Остался один осознанный шаг — merge ^(батник merge^).
)
if defined PRURL echo  PR: %PRURL%
echo ==========================================================================
pause
endlocal
