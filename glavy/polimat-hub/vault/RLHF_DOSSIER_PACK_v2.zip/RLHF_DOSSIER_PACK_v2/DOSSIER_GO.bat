@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
title RLHF DOSSIER - одна кнопка: проверить и открыть
cd /d "%~dp0"
cls

echo ==============================================================================
echo   RLHF_DOSSIER_PACK_v2 — ОДНА КНОПКА
echo   Проверяет целостность пака и открывает досье. Сеть и токены не нужны.
echo ==============================================================================
echo   Папка пака: %CD%
echo.

rem --- [1/3] комплектность пака ---
set "MISSING="
for %%F in ("docs\RLHF_DOSSIER.md" "docs\dossier\RLHF_DOSSIER_PROOFS.html" "docs\dossier\RLHF_DOSSIER_PROOFS.pdf" "docs\dossier\manifest_sha256.txt") do (
  if not exist "%%~F" set "MISSING=%%~F"
)
if defined MISSING (
  echo [1/3] ПРОВАЛ: не найден файл !MISSING!
  echo.
  echo   Похоже, батник запущен из окна архива или архив распакован не весь.
  echo   Распакуй zip ЦЕЛИКОМ: правый клик по архиву — «Извлечь всё...»,
  echo   затем войди в папку RLHF_DOSSIER_PACK_v2 и запусти DOSSIER_GO.bat там.
  echo.
  pause
  exit /b 1
)
echo [1/3] ОК: комплектность — все 4 файла досье на месте.
echo.

rem --- [2/3] целостность: certutil SHA-256 против manifest_sha256.txt ---
set "FAILCNT=0"
for /f "usebackq tokens=1,2" %%A in ("docs\dossier\manifest_sha256.txt") do (
  set "EXP=%%A"
  set "NAME=%%B"
  set "GOT="
  for /f "delims=" %%H in ('certutil -hashfile "docs\dossier\%%B" SHA256 2^>nul ^| findstr /r /c:"^[0-9a-fA-F][0-9a-fA-F]*$"') do if not defined GOT set "GOT=%%H"
  if not defined GOT (
    echo [2/3] ПРОВАЛ: certutil не посчитал хэш для %%B
    set /a FAILCNT+=1
  ) else (
    set "GOT=!GOT: =!"
    if /i not "!GOT!"=="!EXP!" (
      echo [2/3] ПРОВАЛ: %%B — хэш не совпал с манифестом
      echo        ожидалось: !EXP!
      echo        реально:   !GOT!
      set /a FAILCNT+=1
    ) else (
      echo [2/3] ОК: %%B — SHA-256 совпал с манифестом
    )
  )
)
if !FAILCNT! GTR 0 (
  echo.
  echo   ИТОГ: целостность нарушена — файлы повреждены или подменены.
  echo   Скачай zip заново и распакуй целиком, затем запусти батник снова.
  echo.
  pause
  exit /b 1
)
echo.

rem --- [3/3] открыть досье ---
echo [3/3] Открываю досье...
start "" "docs\dossier\RLHF_DOSSIER_PROOFS.html"
start "" notepad "docs\RLHF_DOSSIER.md"
echo       Доказательства — в браузере, досье — в блокноте.
echo.

echo ==============================================================================
echo   ГОТОВО. Целостность подтверждена, досье открыто.
echo     Браузер : docs\dossier\RLHF_DOSSIER_PROOFS.html
echo     Блокнот : docs\RLHF_DOSSIER.md
echo     PDF     : docs\dossier\RLHF_DOSSIER_PROOFS.pdf  ^(открой при желании^)
echo.
echo   Этот пак — ещё и механизм восстановления: POLIMAT_AUTO_PUSH.bat
echo   сам зальёт досье в polymath-os, если оно пропадёт из main.
echo ==============================================================================
echo.
pause
exit /b 0
