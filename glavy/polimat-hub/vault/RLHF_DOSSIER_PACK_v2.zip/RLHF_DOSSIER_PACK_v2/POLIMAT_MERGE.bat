@echo off
chcp 65001 >nul
setlocal EnableExtensions
title POLIMAT MERGE - one click to the finish

rem ============================================================================
rem  Один клик до конца. Сам выбирает путь:
rem   gh установлен и авторизован  -> канонический squash-merge через API,
rem     это POLIMAT_AUTO_PUSH.bat merge: PR получит бейдж Merged.
rem   gh нет или не авторизован    -> локальный squash чистым git,
rem     это POLIMAT_FINISH.bat: тот же итог в main, PR закроется как Closed.
rem  Оба сценария идемпотентны: повторный запуск ничего не задвоит.
rem ============================================================================

set "GHOK=0"
where gh >nul 2>nul
if errorlevel 1 goto nogh
gh auth status >nul 2>nul
if errorlevel 1 goto nogh
set "GHOK=1"

echo gh найден и авторизован - канонический путь: squash-merge через API...
call "%~dp0POLIMAT_AUTO_PUSH.bat" merge
goto end

:nogh
echo gh не найден или не авторизован - локальный путь: POLIMAT_FINISH.bat...
echo gh и браузер не нужны.
call "%~dp0POLIMAT_FINISH.bat"

:end
endlocal
