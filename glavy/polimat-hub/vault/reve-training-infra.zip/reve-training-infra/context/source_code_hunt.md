# Журнал поиска исходного кода (GKR, Warden, драйвер обучения)

Дата поиска: 2026-11-08. Цель: найти публичные репозитории исходников
инфраструктуры, описанной в отчёте «Training Reve 2.0 at scale».

## Что искали и что нашли

| # | Где | Запрос / проверка | Результат |
|---|-----|-------------------|-----------|
| 1 | GitHub: `github.com/reve-art` | официальный аккаунт Reve.art (id 296131913) | **Аккаунт существует, 0 публичных репозиториев.** 1 контрибуция за год (23 июня), репозиторий не виден |
| 2 | GitHub: `github.com/reve` | проверка на случай другого имени | Не он: Alexandru Gheorghita (Бухарест), тулзы EVE Online, 57 репо — нерелевантно |
| 3 | GitHub: `github.com/reve-ai` | проверка | Не он: это Stable Diffusion GUI, нерелевантно |
| 4 | GitHub Search API: `reve training` | 278 совпадений, все — «reverse/revenue training» и пр. | Релевантных нет |
| 5 | Hugging Face: `reve`, `reve-art` | API `/api/users/.../overview`, `/api/models?author=...` | Моделей/датасетов/спейсов от Reve нет; «Reve» на HF — посторонний пользователь |
| 6 | Sourcegraph (глобальный поиск кода) | `"Google Kubernetes Engine Runner"`, `"training-infra@reve.art"` | **0 совпадений** в индексе публичного кода |
| 7 | GitLab.com | `/api/v4/projects?search=reve` | Релевантных нет |
| 8 | Веб-поиск | `site:github.com reve training-infra`, `"gkr" reve`, `"training-infra@reve.art"` и др. | Публикаций кода нет; сайт lhc.media лишь пересказывает отчёт |
| 9 | grep.app (поиск по коду) | `Google Kubernetes Engine Runner`, `gkr submit`, `reve.art` | Сервис закрыт Vercel Security Checkpoint (бот-защита), проверить не удалось |
| 10 | Сам отчёт (страница + PDF) | что пишет команда | Код НЕ выложен: «If you're interested in reference source code, email us at training-infra@reve.art» — только по личному запросу |

## Отдельно замечено

- Страница отчёта помечена как **«An archival technical report»**; авторство:
  **Report by Joe Wang with contributions from Kyra Mo and Ben Cuan**.
- Официальные акаунты Reve: сайт reve.com, blog.reve.com, app.reve.com.
  GitHub org `reve-art` создан, но код не публиковался (и после закрытия
  продукта 27.09–31.10.2026 вероятность публикации ещё ниже).
- GitHub API из песочницы периодически отдаёт rate limit; проверки 1–4 и 8
  продублированы через HTML/веб-поиск — результат согласован.

## Вывод

**Публичных исходников GKR, Warden, драйвера обучения, конфигов запусков
не существует.** Единственный канал — письмо на training-infra@reve.art с
описанием, что именно нужно (это официально предложено в конце отчёта).
