# Архив: «Training Reve 2.0 at scale» — всё, что удалось вытянуть

**Источник:** https://app.reve.com/training-infra
**Дата сбора:** 2026-11-08
**Что это:** технический отчёт Reve Research Team об инфраструктуре обучения мультимодальных
моделей Reve 2.0/2.1 в масштабе 10 000 GPU (Kubernetes + Ray на GCP).
**last-modified оригинала:** 2026-11-06 (сервер nginx, etag 6aee2bac).

---

## Структура архива

```
reve-training-infra/
├── README.md                      ← этот файл (описание + что доступно/недоступно)
├── report_full.md                 ← ПОЛНЫЙ ТЕКСТ отчёта, извлечённый в Markdown
│                                     (все 9 разделов + References + BibTeX, 4 таблицы,
│                                      6 блоков кода, подписи схем)
├── reve-full-report.pdf           ← ОФИЦИАЛЬНЫЙ PDF-отчёт с сайта (8 страниц, 893 КБ)
├── page_raw.html                  ← сырой HTML страницы (189 КБ, со всеми схемами,
│                                     формулами KaTeX и контентом; открыть локально —
│                                     отрисуется со стилями из assets/css)
├── links_inventory.txt            ← реестр всех 47 внешних URL со страницы (29 доменов)
├── all_urls.json                  ← тот же реестр в JSON (сгруппирован по доменам)
├── assets/
│   ├── img/                       ← 17 изображений: hero-atlas, social-preview, icon.svg,
│   │                                галерея карусели сайта (hero-carousel-1..13)
│   ├── media/board-full-v3.mp4    ← видео «layout streaming» из Reve 2.0 (3 МБ, Figure 1)
│   └── css/                       ← 6 CSS-файлов сайта (style, print, katex,
│                                    infra-figures.generated, theme.reve, navigation) —
│                                    нужны для локального отображения HTML
└── context/
    ├── CONTEXT_ru.md              ← контекст: что такое Reve, судьба продукта,
    │                                архивные копии, каналы связи (с источниками)
    ├── source_code_hunt.md        ← ЖУРНАЛ ПОИСКА ИСХОДНИКОВ: GitHub (org reve-art —
    │                                существует, но 0 репо), HF, GitLab, Sourcegraph —
    │                                публичного кода НЕ существует, только по email
    ├── reve-blog-layout-bet.txt   ← текст поста «The Layout Bet» (блог Reve, 03.06.2026)
    ├── reve-blog-layout-bet.html  ← сырой HTML этого поста
    └── wayback_check.json         ← ответ API Wayback Machine (есть снапшот от 28.10.2026)
```

## Содержание отчёта (что внутри текста)

- **01 System Overview** — Kubernetes как compute-платформа, Ray для распределённого
  обучения, GCP; GKR (Google Kubernetes Engine Runner) — внутренний CLI; KubeRay,
  PyTorch/Ray Train, Warden; GitOps через ArgoCD + Terraform + Kustomize.
- **02 Workload Interface and Submission Flow** — единый CLI GKR, конфигурация jobs
  (CLI/YAML + Jinja-шаблоны), Hydra для конфигурации приложения, префлайт-проверки
  (kernel-логи, тесты коллективных операций) перед запуском.
- **03 Platform Deployment** — GCP future reservations (вместо spot), контракты на
  железо (A3/H200), провижининг и доставка образов.
- **04 Cluster-level Job Orchestration** — admission и placement, приоритеты/вытеснение
  (preemptibility), жизненный цикл job.
- **05 Distributed Execution in Ray** — координация RayCluster, вспомогательные worker'ы,
  capacity planning, размещение worker'ов, пайплайн обучающих данных.
- **06 Cross-region Jobs** — local learners, барьерный и decoupled режимы.
- **07 Failure Containment and Recovery** — чекпоинты, Ray auto-shrink и torchft,
  авторемонт узлов через Warden, автоматический анализ сбоев и перезапуск.
- **08 Observability and Performance Diagnostics** — метрики/логи/дашборды
  (ClickHouse, Prometheus, Grafana, Fluent Bit, OpenTelemetry), диагностика NCCL
  (flight recorder, NCCL inspector).
- **09 Conclusion**, **References** (42 источника со ссылками), **BibTeX**.

## Доступное vs недоступное

### Получено (всё, что сервер отдаёт публично)
1. Полный HTML страницы (с вёрсткой схем и формул) — `page_raw.html`.
2. Официальный PDF отчёта — `reve-full-report.pdf`.
3. Полный текст в Markdown — `report_full.md`.
4. Видеофигура (Figure 1, layout streaming Reve 2.0) — `assets/media/board-full-v3.mp4`.
5. Все картинки страницы + CSS для локального просмотра.
6. Реестр всех внешних ссылок (47 шт., 29 доменов).
7. Пост-компаньон блога «The Layout Bet».
8. Контекст о компании и закрытии продукта (с источниками).

### Недоступно / не публикуется (проверено)
1. **Исходный код инфраструктуры (GKR, Warden, драйвер обучения)** — публично НЕ
   существует (проверено 2026-11-08: GitHub org `reve-art` — официальный аккаунт,
   но 0 репозиториев; GitHub/GitLab/HF/Sourcegraph — ничего; подробный журнал
   поиска — `context/source_code_hunt.md`). Команда распространяет референсный код
   только по личному запросу на **training-infra@reve.art** (так написано в отчёте).
2. **Конфиги реальных запусков, веса моделей, датасеты** — нигде не опубликованы.
3. **Полные векторные версии схем отдельными файлами (SVG/PNG)** — сервер их не отдаёт:
   схемы рисуются HTML+CSS прямо на странице; их точный вид — в `page_raw.html`,
   `reve-full-report.pdf` и (текстом) в `report_full.md`.
4. **Веб-версия страницы с внешним CDN-контентом** — весь контент отдаётся с самого
   app.reve.com, внешних подгрузок в HTML нет.
5. **Снапшот Wayback Machine** (от 28.10.2026) — сервер web.archive.org не ответил
   из песочницы (таймаут); URL записан в `context/CONTEXT_ru.md`. Версия в этом архиве —
   более свежая (6 ноября 2026).

## Как смотреть

- Быстро читать: `report_full.md`.
- Официальная вёрстка: открыть `reve-full-report.pdf`.
- Посмотреть страницу «как живую»: открыть `page_raw.html` (стили подтянутся из `assets/css`,
  если открыть файл в браузере из папки архива).
- Видео: `assets/media/board-full-v3.mp4` (пример генерации layout в Reve 2.0).
