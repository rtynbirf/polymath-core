# JOHNSON v3.6.0

## Trust-domain hardening
- Added `RootTrustAuthority` for root authorization of signing-key epochs.
- Added `SigningTrustDomain` for checkpoint authentication.
- Root and signing envelopes are type/domain separated.
- Added epoch rollback and old-key resurrection guards.
- Added cross-domain replay guards.
- Added checkpoint epoch and revoked-epoch checks.
- Added adversarial tests T94–T103.

## Verification
- `python polymath_agent_JOHNSON_v3.6.0.py --selftest`
- Result: **98/98 PASS**
- Exit code: **0**

## Important boundary
This is an in-process trust-domain separation, not hardware/OS isolation of the root key.
The ledger trust anchor remains externally pinned and explicitly non-self-authenticating.
