# JOHNSON v3.6.0

ROOT trust epoch / rotation / history hardening.

Added append-only root epochs, parent binding, rollback/truncation detection, fingerprint reuse detection, fork detection, authorization tamper detection, active/checkpoint validation, and adversarial tests T94-T103.

Scope: in-runtime trust-history layer; no process-level TCB isolation claim.
