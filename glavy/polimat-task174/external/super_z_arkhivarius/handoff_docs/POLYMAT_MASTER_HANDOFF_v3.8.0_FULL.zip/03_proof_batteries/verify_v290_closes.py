#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Контроль закрытия дефектов: те же пробы, что доказали D1/D2 на v2.8.0,
выполняются против v2.9.0. Ожидание — оба дефекта закрыты (exit 0)."""
import importlib.util
import sys

V280 = "/home/z/my-project/agent_1/polymath_agent_v2.8.0.py"
V290 = "/home/z/my-project/agent_1/polymath_agent_v2.9.0.py"

RULE = "claim_witnessed_by_successful_action_observation"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def probe_d1(m):
    """Мёртвые предикаты: выжигание реестра НЕ должно менять вердикт entails.
    Дефект = verdict_burned == verdict_normal. Фикс = True, False."""
    claim = m.Claim("claim:1", "capability:write_file выполнена", "capability", "write_file")
    ev = [m.EvidenceObject("e1", "", "observation", "step:1", m.sha256_hex(b"x"),
                           "2026-08-28T00:00:00+00:00", True, "write_file", True)]
    contract = m.EvidenceContract("claim:1", required_capability="write_file")
    ok_normal = m.TypedRuleEngine(m.RuleRegistry(), m.PredicateRegistry()).entails(RULE, claim, ev, contract)
    eng = m.TypedRuleEngine(m.RuleRegistry(), m.PredicateRegistry())
    eng.predicates._predicates.clear()
    ok_burned = eng.entails(RULE, claim, ev, contract)
    return ok_normal, ok_burned, (ok_normal == ok_burned)


def probe_d2(m):
    """Нет распространения UNKNOWN: assertion-claim не должен получать валидный вывод,
    пока его предпосылка (capability-claim) не доказана. Фикс требует depends_on."""
    state = {
        "criteria": ["capability:write_file выполнена успешно", "итоговый отчёт записан"],
        "required_capabilities": ["write_file", "web_search"],
        "criteria_deps": {"итоговый отчёт записан": ["capability:write_file выполнена успешно"]},
        "ledger": [{"step": 1, "action": "web_search", "ok": True, "kind": "net",
                    "obs_brief": "search results"}],
    }
    proof = m.ProofCompiler(state).compile()
    has_depends_on = hasattr(m.Claim(id="x", text="y"), "depends_on")
    valid_assertion = [d for d in state.get("derivations", [])
                       if d.get("claim_id") == "claim:2" and d.get("valid") and d.get("evidence_ids")]
    blocked = proof.claim_status.get("claim:2") if hasattr(proof, "claim_status") else None
    return {
        "has_depends_on": has_depends_on,
        "valid_derivation_for_blocked_claim": len(valid_assertion),
        "claim2_status": blocked,
        "overall": proof.status,
    }


if __name__ == "__main__":
    m280 = load(V280, "v280")
    m290 = load(V290, "v290")

    n280, b280, d1_280 = probe_d1(m280)
    n290, b290, d1_290 = probe_d1(m290)
    print(f"D1 v2.8.0: normal={n280} burned={b280} -> дефект воспроизводится: {d1_280}")
    print(f"D1 v2.9.0: normal={n290} burned={b290} -> дефект воспроизводится: {d1_290}")
    assert d1_280 and not d1_290 and n290 and not b290, "D1 не закрыт"

    r280 = probe_d2(m280)
    r290 = probe_d2(m290)
    print(f"D2 v2.8.0: {r280}")
    print(f"D2 v2.9.0: {r290}")
    assert not r280["has_depends_on"] and r280["valid_derivation_for_blocked_claim"] >= 0, "D2 база изменилась"
    assert r290["has_depends_on"], "v2.9.0: depends_on отсутствует"
    assert r290["claim2_status"] == "blocked", "v2.9.0: зависимый claim не заблокирован"
    assert r290["valid_derivation_for_blocked_claim"] == 0, "v2.9.0: вывод для заблокированного claim существует"
    assert r290["overall"] == "unknown", "v2.9.0: агрегат должен быть unknown"

    print("ИТОГ: D1 закрыт, D2 закрыт — пробы v2.8.0 не воспроизводятся на v2.9.0")
    sys.exit(0)
