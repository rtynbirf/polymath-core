#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""МЕХАНИЧЕСКОЕ ДОКАЗАТЕЛЬСТВО: дефекты v2.0.1 против исправлений v2.1.0.

Запуск:  python3 proof_v201_defects.py [путь_к_версии.py]
  * v2.0.1 (по умолчанию): оба дефекта ВОСПРОИЗВОДЯТСЯ
      1) продакшн ActionDAG пуст (web_search вне плана, deps=[])
      2) DNS-rebinding TOCTOU: секрет с 127.0.0.1 получен
  * v2.1.0: скрипт доказывает ОБРАТНОЕ (план содержит web_search,
    deps заполнены, rebinding заблокирован, dial по валидированному IP)
"""
import socket, sys, threading, http.server, importlib.util, json

TARGET = sys.argv[1] if len(sys.argv) > 1 else "/home/z/my-project/agent_chain/polymath_agent_v2.0.1.py"
IS_V210 = "v2.1.0" in TARGET or "v210" in TARGET

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

V = load(TARGET, "poly_target")
import tempfile, os
from pathlib import Path

td = tempfile.mkdtemp(prefix="proof_")
cfg, _ = V._fresh_cfg(td)
gov = V.Governor(cfg, V.AuditChain(Path(td) / "a.jsonl"), V.CatalogBridge(""))

# ── ПРОВЕРКА 1: продакшн-компиляция ActionDAG ────────────────────────────────
print("=" * 72)
print(f"ПРОВЕРКА 1 [{TARGET.split('/')[-1]}]: production ActionDAG (как строит Agent.solve)")
g = V.CapabilityGraph(gov.registry)                 # ровно как в Agent.__init__
spec = V.FormalGoalCompiler().compile_spec(
    "исследуй тему через интернет и запиши отчёт", gov.registry, V.CapabilityPlanner(g))
dag = V.ActionDAG(spec, g)
print(f"  spec.capabilities      = {spec.capabilities}")
print(f"  web_search в плане?    = {'web_search' in spec.capabilities}")
print(f"  depends_on всех нод    = { {k: v.depends_on for k, v in dag.nodes.items()} }")
empty = all(not n.depends_on for n in dag.nodes.values())
print(f"  ВЕРДИКТ: dependency guard мёртв в бою: {empty}")
if not IS_V210:
    assert "web_search" not in spec.capabilities, "ожидался дефект: web_search вне плана"
    assert empty, "ожидался дефект: пустые depends_on"
else:
    assert "web_search" in spec.capabilities, "v2.1.0: web_search обязан быть в плане"
    assert not empty, "v2.1.0: depends_on обязан быть заполнен"

# ── ПРОВЕРКА 2: DNS TOCTOU / rebinding ───────────────────────────────────────
print("=" * 72)
print(f"ПРОВЕРКА 2 [{TARGET.split('/')[-1]}]: DNS rebinding (guard видит публичный IP, dial — приватный)")

class Quiet(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200); self.send_header("Content-Type", "text/plain")
        self.end_headers(); self.wfile.write(b"SECRET_FROM_LOCALHOST")
    def log_message(self, *a): pass
srv = http.server.HTTPServer(("127.0.0.1", 0), Quiet)
port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

HOST = "evil.example.com"
real_getaddrinfo = socket.getaddrinfo
resolve_log = []
calls = {"n": 0}
def rebinding_getaddrinfo(host, port=None, *a, **kw):
    if host == HOST:
        calls["n"] += 1
        ip = "93.184.216.34" if calls["n"] == 1 else "127.0.0.1"   # 1=guard, 2=dial
        sa = (ip, port if port else 80)
        resolve_log.append(sa)
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", sa)]
    return real_getaddrinfo(host, *a, **kw)

socket.getaddrinfo = rebinding_getaddrinfo
resolve_log.clear(); calls["n"] = 0
try:
    obs, _fp = gov.run("proof", 1, "http_get", {"url": f"http://{HOST}:{port}/x"})
finally:
    socket.getaddrinfo = real_getaddrinfo
    srv.shutdown()

print(f"  вызовов resolver'a: {calls['n']}")
print(f"  резолвы: {resolve_log}")
print(f"  obs.ok = {obs.ok}; kind = {obs.kind}; содержимое: {obs.brief(120)!r}")
rebinded = bool(obs.ok) and "SECRET_FROM_LOCALHOST" in obs.content and resolve_log[-1][0] == "127.0.0.1"
print(f"  ВЕРДИКТ: DNS-rebinding УСПЕШЕН (секрет внутреннего сервера получен): {rebinded}")
if not IS_V210:
    assert rebinded, "ожидался дефект: rebinding должен был пройти"
    print("=" * 72)
    print("ОБА ДЕФЕКТА ПОДТВЕРЖДЕНЫ МЕХАНИЧЕСКИ НА v2.0.1")
else:
    assert not obs.ok, "v2.1.0: атака обязана быть отклонённой"
    assert not rebinded, "v2.1.0: секрет получить НЕ УДАЛОСЬ"
    print("=" * 72)
    print("v2.1.0: АТАКА ЗАБЛОКИРОВАНА, ПЛАН ПОЛОН — ДЕФЕКТЫ v2.0.1 ИСПРАВЛЕНЫ")
