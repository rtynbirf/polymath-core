#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка polymath_agent v2.2.0 «Proof Gate + Claim Compiler»:
слияние двух веток v2.1.0 (ProofObject-ветка пользователя + DNS-pinning/DataFlow-ветка)
и закрытие трёх доказанных дефектов. Каждый сплайс проверяется на уникальность якоря."""
import sys, pathlib

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import v220_blocks as B
import v220_tests as T

SRC = pathlib.Path("/home/z/my-project/upload/polymath_agent_v2.1.0.py")
DST = pathlib.Path("/home/z/my-project/download/polymath_agent_v2.2.0.py")

text = SRC.read_text(encoding="utf-8")
applied = []

def splice(name, old, new, count=1):
    global text
    found = text.count(old)
    assert found == count, f"[{name}] якорь найден {found} раз (ожидалось {count})"
    text = text.replace(old, new)
    applied.append(name)

# ── 1. Заголовок и changelog ──
splice("header", B.HEADER_TITLE_OLD, B.HEADER_TITLE_NEW)

# ── 2. Импорт http.client для pinned-соединений ──
splice("import-http-client", "import http.server\n", "import http.client\nimport http.server\n")

# ── 3. Pinned-сетевой стек (ветка Б): _http_request_no_redirect ──
splice("http-request-fn",
       '''def _http_request_no_redirect(url: str, cfg: "Config", method: str = "GET", data: Optional[bytes] = None):
    _ssrf_guard(url)
    req = urllib.request.Request(url, data=data, method=method, headers={
        "User-Agent": "polymath-agent/1.3 (+local research tool)",
        "Accept": "text/html, text/plain, application/json, application/xml;q=0.9,*/*;q=0.5"})
    opener = urllib.request.build_opener(_NoRedirect)
    return opener.open(req, timeout=cfg.net_timeout_s)''',
       B.NEW_HTTP_REQUEST_FN)

# ── 4. _ssrf_guard → guard + resolve_host + pinned-соединения ──
splice("ssrf-pinning",
       '''def _ssrf_guard(url: str) -> None:
    """GET-only наружу; приватные/резервные сети запрещены (best-effort DNS-пиннинг)."""
    m = re.match(r"^https?://[^/]+", url or "")
    if not m:
        raise PolicyViolation("url обязан быть абсолютным http(s)-адресом")
    host = re.match(r"^https?://([^/:?#]+)", url).group(1).strip("[]").lower()
    if host in _BAD_HOSTNAMES:
        raise PolicyViolation(f"SSRF-фильтр: хост '{host}' запрещён")
    if host.endswith(".local") or host.endswith(".internal"):
        raise PolicyViolation(f"SSRF-фильтр: домен внутренней зоны '{host}' запрещён")
    try:
        infos = socket.getaddrinfo(host, None)
    except OSError as e:
        raise PolicyViolation(f"SSRF-фильтр: DNS-резолв не удался ({e}) — блокирую")
    for info in infos:
        addr = ipaddress.ip_address(info[4][0])
        if (addr.is_private or addr.is_loopback or addr.is_link_local
                or addr.is_reserved or addr.is_multicast):
            raise PolicyViolation(f"SSRF-фильтр: адрес {addr} относится к приватным сетям")''',
       B.NEW_SSRF_BLOCK)

# ── 5. ДЕФЕКТ 3: _t_http_get идёт через pinned opener ──
splice("http-get-pinned",
       '''        # Redirects запрещены здесь намеренно: новый URL должен пройти SSRF-проверку заново.
        with urllib.request.build_opener(_NoRedirect).open(req, timeout=cfg.net_timeout_s) as resp:''',
       '''        # Redirects запрещены здесь намеренно: новый URL должен пройти SSRF-проверку заново.
        # v2.2.0 (дефект 3 закрыт): соединение ТОЛЬКО по валидированному IP (DNS-pinning) —
        # повторный резолв, которым пользуется rebinding-атака, механически исключён.
        with _pinned_opener().open(req, timeout=cfg.net_timeout_s) as resp:''')

# ── 6. _substitute_vars → 3-выход (args, missing, substituted) ──
splice("substitute-vars",
       '''def _substitute_vars(args: Any, state: Dict[str, Any]) -> Tuple[Any, bool]:
    """Механическая подстановка $last_output — вывод последнего успешного действия —
    в args действия. Рекурсия по dict/list; замена ТОЛЬКО точного совпадения строки
    (строка, равная переменной целиком), чтобы не калечить данные модели.
    Возвращает (args, missing): missing=True, если переменная упомянута, но ещё
    не существует — вызов будет честно отклонён с объяснением."""
    missing = [False]

    def walk(x):
        if isinstance(x, str):
            if x.strip() == LAST_OUTPUT_VAR:
                lo = state.get("_last_output")
                if lo is None:
                    missing[0] = True
                    return x
                return lo
            return x
        if isinstance(x, dict):
            return {k: walk(v) for k, v in x.items()}
        if isinstance(x, list):
            return [walk(v) for v in x]
        return x

    return walk(args), missing[0]''',
       B.NEW_SUBSTITUTE_VARS)

# ── 7. Governor: снимок/восстановление идемпотентности ──
splice("governor-se",
       '''        self._seen_side_effect: Dict[str, int] = {}

    # --- реестр: промпт документируется ТОЛЬКО отсюда (анти-Ф4) ---''',
       '''        self._seen_side_effect: Dict[str, int] = {}
''' + B.GOVERNOR_SE_METHODS + '''
    # --- реестр: промпт документируется ТОЛЬКО отсюда (анти-Ф4) ---''')

# ── 8. GoalCompiler: эвристика веб-маркеров (ветка Б) ──
splice("goal-compiler",
       '''class GoalCompiler:
    """Компилирует цель в проверяемую спецификацию выполнения."""
    def compile(self, goal, registry):
        g=goal.strip(); low=g.lower()
        requested=[]
        if any(x in low for x in ("интернет","веб","источник","исслед","найди","сравн")):
            requested.append("research_web" if "research_web" in registry else "web_search")''',
       '''class GoalCompiler:
    """Компилирует цель в проверяемую спецификацию выполнения.
    v2.2.0 (ветка Б): эвристика ужесточена — «найди»/«сравн» сами по себе больше НЕ
    триггерят веб-контур (ложные срабатывания на локальные задачи: «найди файл»),
    только явные веб-маркеры («интернет», «веб», «источник», «исслед», «http(s)://»)."""
    def compile(self, goal, registry):
        g=goal.strip(); low=g.lower()
        requested=[]
        web_markers = ("интернет","веб","источник","исслед","http://","https://")
        if any(x in low for x in web_markers):
            requested.append("research_web" if "research_web" in registry else "web_search")''')

# ── 9. CapabilityGraph + DependencyKnowledge (ветка Б) ──
splice("capability-graph",
       '''class CapabilityGraph:
    """Граф возможностей и зависимостей."""
    def __init__(self, registry):
        self.nodes={n:{"name":n,"risk":sp.risk,"description":sp.doc,"deps":[]} for n,sp in registry.items()}
    def add_dependency(self, name, dep):''',
       B.CAPABILITY_GRAPH_NEW[:B.CAPABILITY_GRAPH_NEW.index("    def add_dependency(self, name, dep):")] +
       '''    def add_dependency(self, name, dep):''')

# ── 10. DataFlowGraph перед ExecutionGraph (ветка Б) ──
splice("dataflow-class", "class ExecutionGraph:", B.DATAFLOW_CLASS + "class ExecutionGraph:")

# ── 11. ActionDAG.restore_snapshot (дефект 2) ──
splice("actiondag-restore",
       '    def all_required_completed(self): return all(n.status=="completed" for n in self.nodes.values())',
       B.RESTORE_SNAPSHOT_METHOD +
       '    def all_required_completed(self): return all(n.status=="completed" for n in self.nodes.values())')

# ── 12. ProofObject: поле claims (ветка А расширена) ──
splice("proofobject-claims", B.PROOF_OBJECT_FIELD_OLD, B.PROOF_OBJECT_FIELD_NEW)

# ── 13. Claim/ClaimType/ProofCompiler после _proof_level_from_observation ──
splice("claim-compiler",
       '''def _proof_level_from_observation(obs_ok: bool, verified: bool = False) -> str:
    if verified and obs_ok: return "VERIFIED"
    if obs_ok: return "OBSERVED"
    return "ATTEMPTED"


''',
       '''def _proof_level_from_observation(obs_ok: bool, verified: bool = False) -> str:
    if verified and obs_ok: return "VERIFIED"
    if obs_ok: return "OBSERVED"
    return "ATTEMPTED"


''' + B.CLAIM_BLOCKS)

# ── 14. Agent.__init__: dataflow + proof_compiler ──
splice("agent-init",
       '''        self.execution_graph = None
        self.action_dag = None''',
       '''        self.execution_graph = None
        self.action_dag = None
        self.dataflow = DataFlowGraph()          # v2.2.0: семантический поток данных задачи
        self.proof_compiler = ProofCompiler()    # v2.2.0: компилятор доказательств (гейт вердикта)''')

# ── 15. Resume: демоция running→pending + dataflow (дефект 2) ──
splice("resume-dag",
       '''                self.execution_graph=ExecutionGraph(spec).compile()
                self.action_dag=ActionDAG(spec,self.capabilities)
                for cap, snap in state.get("action_dag", {}).items():
                    if cap in self.action_dag.nodes:
                        self.action_dag.nodes[cap].status=snap.get("status", "pending")
                eg=state.get("execution_graph", {})''',
       '''                self.execution_graph=ExecutionGraph(spec).compile()
                self.action_dag=ActionDAG(spec,self.capabilities)
                # v2.2.0 (дефект 2 закрыт): restore с демоцией running→pending — слепое
                # восстановление running замораживало ноду навсегда (start() требует
                # pending, complete() требует running)
                self.action_dag.restore_snapshot(state.get("action_dag", {}))
                # v2.2.0: восстановление семантического DataFlowGraph задачи
                self.dataflow.restore_snapshot(state.get("dataflow", {}))
                eg=state.get("execution_graph", {})''')

splice("resume-se",
       '            log("RESUME", f"восстановлен checkpoint шага {restored_step}: {cp_path}")',
       '''            # v2.2.0: идемпотентность побочных вызовов переживает resume
            self.gov.restore_seen_side_effect(state.get("_seen_side_effect", {}))
            state.setdefault("_seen_side_effect", {})
            log("RESUME", f"восстановлен checkpoint шага {restored_step}: {cp_path}")''')

# ── 16. Свежий state: _seen_side_effect ──
splice("fresh-state",
       '''            "_provenance_ids": [],
            "proof": None,''',
       '''            "_provenance_ids": [],
            "_seen_side_effect": {}, # v2.2.0: идемпотентность побочных вызовов (переживает checkpoint)
            "proof": None,''')

# ── 17. Свежая цель: dataflow в state ──
splice("fresh-goal",
       '''            state["action_dag"]=self.action_dag.snapshot()
            self.provenance.append("goal_compiled"''',
       '''            state["action_dag"]=self.action_dag.snapshot()
            state["dataflow"]=self.dataflow.snapshot()   # v2.2.0
            self.provenance.append("goal_compiled"''')

# ── 18. Act-путь: 3-выход подстановки + DataFlow-интеграция ──
splice("act-path",
       '''                    act_args, lo_missing = _substitute_vars(act.get("args", {}), state)
                    if lo_missing:
                        obs = Observation(False, "policy",
                                          "переменная $last_output недоступна: ни одного успешного "
                                          "действия в задаче ещё не было — сначала выполни действие-источник")
                        fp = None
                    else:
                        cap=act["name"]
                        tracked = cap in (self.action_dag.nodes if self.action_dag else {})
                        try:
                            if tracked: self.action_dag.start(cap)
                            obs, fp = self.gov.run(task_id, step_idx, cap, act_args)
                            if tracked: self.action_dag.complete(cap, obs)
                        except PolicyViolation as e:
                            obs=Observation(False,"policy",str(e)); fp=None
                            if tracked and self.action_dag.nodes[cap].status=="running": self.action_dag.complete(cap,obs)
                    obs_list.append((step_idx, obs))
                    if self.action_dag: state["action_dag"]=self.action_dag.snapshot()''',
       '''                    act_args, lo_missing, lo_substituted = _substitute_vars(act.get("args", {}), state)
                    if lo_missing:
                        obs = Observation(False, "policy",
                                          "переменная $last_output недоступна: ни одного успешного "
                                          "действия в задаче ещё не было — сначала выполни действие-источник")
                        fp = None
                    else:
                        cap=act["name"]
                        tracked = cap in (self.action_dag.nodes if self.action_dag else {})
                        try:
                            if tracked: self.action_dag.start(cap)
                            # v2.2.0: DataFlow guard — заблокированная нода не исполняется
                            if self.dataflow:
                                self.dataflow.check_executable(cap)
                                if lo_substituted:
                                    edge = self.dataflow.link_consumer(cap)
                                    if edge:  # поток данных = поток доказательств
                                        self.evidence_graph.link(f"action:{edge['src']}", "feeds", f"action:{edge['dst']}")
                                if not tracked:
                                    self.dataflow.note_orphan(cap)   # честная видимость вне-DAG действий
                                self.dataflow.mark_running(cap)
                            obs, fp = self.gov.run(task_id, step_idx, cap, act_args)
                            if tracked: self.action_dag.complete(cap, obs)
                        except PolicyViolation as e:
                            obs=Observation(False,"policy",str(e)); fp=None
                            if tracked and self.action_dag.nodes[cap].status=="running": self.action_dag.complete(cap,obs)
                        # v2.2.0: компиляция потока данных по факту наблюдения
                        if self.dataflow:
                            if obs.ok:
                                self.dataflow.mark_done(cap)
                                if obs.kind != "write":
                                    # источник нового _last_output (те же условия, что и у переменной)
                                    self.dataflow.note_producer(cap, step_idx)
                            else:
                                # downstream invalidation: провал producer'а блокирует потребителей
                                self.dataflow.invalidate_downstream(cap)
                    obs_list.append((step_idx, obs))
                    if self.action_dag: state["action_dag"]=self.action_dag.snapshot()
                    if self.dataflow: state["dataflow"]=self.dataflow.snapshot()''')

# ── 19. Act-хвост: синхронизация идемпотентности в state ──
splice("act-tail",
       '''                last_observations = obs_list
                stall = 0 if new_artifact else stall + 1''',
       '''                # v2.2.0: идемпотентность побочных вызовов сохраняется в state
                state["_seen_side_effect"] = self.gov.seen_side_effect_snapshot()
                last_observations = obs_list
                stall = 0 if new_artifact else stall + 1''')

# ── 20. ДЕФЕКТ 1: PROOF GATE в пути вердикта ──
splice("proof-gate",
       '''                        last_observations = [(step_idx, Observation(False, "verify", warn))]
                        stall += 1
                        continue
                    for c in state.get("criteria", []):   # кумулятивная фиксация''',
       '''                        last_observations = [(step_idx, Observation(False, "verify", warn))]
                        stall += 1
                        continue
                    # v2.2.0 (дефект 1 закрыт): PROOF GATE — вердикт VERIFIED компилируется,
                    # а не объявляется. Дефект v2.1.0: _proof_allows_verified вызывался
                    # только в тестах, _finalize штамповал proof_level="VERIFIED" пост-фактум.
                    # Теперь доказательство СНАЧАЛА компилируется из claims (ProofCompiler:
                    # ACTION/FACT/ARTIFACT контракты), и только механическое решение гейта
                    # открывает VERIFIED. ProviderSuccess ⊬ Claim — теперь и в runtime.
                    proof = self.proof_compiler.derive(task_id, state)
                    if not Agent._proof_allows_verified(proof, state):
                        warn = ("VERIFIED ОТКЛОНЁН Proof-гейтом: компилятор доказательств не собрал "
                                "VERIFIED из claims (пустой evidence_set или недоказанные claims): "
                                + "; ".join((proof.unknown_set or ["evidence_set пуст — ни одного успешного наблюдения"])[:3]))
                        log("VERIFY", warn)
                        state["ledger"].append({"step": step_idx, "action": "(verify-fail)",
                                                "ok": False, "kind": "verify",
                                                "obs_brief": warn})
                        last_observations = [(step_idx, Observation(False, "verify", warn))]
                        stall += 1
                        continue
                    state["proof"] = proof.as_dict()   # скомпилированный proof — единственный источник VERIFIED
                    for c in state.get("criteria", []):   # кумулятивная фиксация''')

# ── 21. _finalize: dataflow + идемпотентность в state; proof_level в эпизоде ──
splice("finalize-state",
       '        if self.action_dag: state["action_dag"] = self.action_dag.snapshot()',
       '''        if self.action_dag: state["action_dag"] = self.action_dag.snapshot()
        if self.dataflow: state["dataflow"] = self.dataflow.snapshot()   # v2.2.0
        state["_seen_side_effect"] = self.gov.seen_side_effect_snapshot()   # v2.2.0''')

splice("finalize-prooflevel",
       '        result["answer"] = answer',
       '''        result["answer"] = answer
        result["proof_level"] = (state.get("proof") or {}).get("proof_level", "UNKNOWN")   # v2.2.0''')

# ── 22. T16 → 3-выход подстановки ──
splice("t16-unpack-1",
       '            args, missing = _substitute_vars({"path": "o.txt", "content": "$last_output"}, state)',
       '            args, missing, _sub = _substitute_vars({"path": "o.txt", "content": "$last_output"}, state)',
       count=2)
splice("t16-assert",
       '            assert not missing and args["content"] == "git version 2.47.3", "подстановка не сработала"',
       '''            assert not missing and args["content"] == "git version 2.47.3", "подстановка не сработала"
            assert _sub is True, "substituted-флаг не взведён при реальной подстановке"''')
splice("t16-unpack-2",
       '            args, _ = _substitute_vars({"a": ["$last_output", "x"], "b": {"c": "$last_output"}}, state)',
       '            args, _, _sub_a = _substitute_vars({"a": ["$last_output", "x"], "b": {"c": "$last_output"}}, state)')
splice("t16-unpack-3",
       '            args, _ = _substitute_vars({"content": "prefix $last_output suffix"}, state)',
       '            args, _, _sub_p = _substitute_vars({"content": "prefix $last_output suffix"}, state)\n            assert _sub_p is False, "частичная подстановка запрещена — флаг обязан быть False"')

# ── 23. Новые тесты T44–T54 ──
splice("new-tests",
       '    check("T46 proof object", t_proof_object_not_enum)',
       T.NEW_TESTS_BLOCK + '    check("T46 proof object", t_proof_object_not_enum)')

splice("new-checks",
       '    check("T47 provider success is not proof", t_provider_success_not_proof)',
       '''    check("T47 provider success is not proof", t_provider_success_not_proof)
    check("T44 production dependency knowledge", t_production_dependency_knowledge)
    check("T45 dns pinning blocks rebinding", t_dns_pinning_blocks_rebinding)
    check("T48 dataflow compile and guard", t_dataflow_compile_and_guard)
    check("T49 dataflow downstream invalidation", t_dataflow_downstream_invalidation)
    check("T50 idempotency across resume", t_side_effect_idempotency_across_resume)
    check("T51 running status demoted on resume", t_running_status_demoted_on_resume)
    check("T52 dataflow orphan visibility", t_dataflow_orphan_visibility)
    check("T53 runtime proof gate rejects unproven verified", t_runtime_proof_gate_rejects_unproven)
    check("T54 claim compiler contracts", t_claim_compiler_contracts)''')

DST.write_text(text, encoding="utf-8")
print(f"OK: применено сплайсов: {len(applied)}")
for a in applied:
    print("  •", a)
print(f"Файл: {DST} ({len(text)} символов, {text.count(chr(10))+1} строк)")
