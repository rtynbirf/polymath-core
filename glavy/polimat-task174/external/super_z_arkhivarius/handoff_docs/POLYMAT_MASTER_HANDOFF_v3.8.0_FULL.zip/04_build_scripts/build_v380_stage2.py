#!/usr/bin/env python3
"""
build_v380_stage2.py — вставка тестов T121–T136 (ROOT EPOCH CHAIN) в selftest v3.8.0.

T121–T126 — новые пробы production-пути (анти-«мёртвый слой»):
  T121 e2e: активная корневая эпоха вшита в proof/commit/ledger (N-RT3 закрыт)
  T122 e2e: усечение хвоста корневой истории блокирует COMMIT (N-RT1 закрыт)
  T123 e2e: отозванный корень блокирует COMMIT в контракте исключений (N-RT4)
  T124 unit: двойной revoke + ротация от отозванного корня отклоняются (N-RT2)
  T125 unit: replay отклоняет откат корневой эпохи в журнале
  T126 unit: историческая валидация эпох (старая — валидна, неизвестная/отозванная — нет)

T127–T136 — порт 10 проб ветки ROOT_TRUST (её T94–T103) на RootEpochChain;
  T130 УСИЛЕН: усечение ловится пином на production-пути, а не «digest differs».
"""
from pathlib import Path

SRC = Path("/home/z/my-project/download/polymath_agent_v3.8.0.py")
text = SRC.read_text(encoding="utf-8")
applied = []


def splice(anchor, replacement, name, count=1, mode="replace"):
    global text
    found = text.count(anchor)
    assert found == count, f"[{name}] anchor found {found} times (expected {count})"
    if mode == "replace":
        text = text.replace(anchor, replacement)
    elif mode == "after":
        text = text.replace(anchor, anchor + replacement)
    applied.append(name)


TEST_DEFS = '''
    # ═════════════════════════════════════════════════════════════════════════
    # v3.8.0 ROOT EPOCH CHAIN — T121–T136 (ROOT → Proof → CAS → Revocation →
    # Reconciliation → COMMIT как механически проверяемая дуга)
    # ═════════════════════════════════════════════════════════════════════════

    def t_runtime_root_epoch_bound_to_commit() -> str:
        # v3.8.0 N-RT3 e2e: цепь не мёртвый код — активная эпоха вшита в proof,
        # commit-запись и ledger COMMIT живым runtime'ом (Agent.solve).
        with tempfile.TemporaryDirectory() as tmp:
            cfg, ws = _fresh_cfg(tmp)
            Path(ws).mkdir(parents=True, exist_ok=True)
            script=[
                {"thought": "План.", "status": "plan",
                 "success_criteria": ["hello.txt содержит 'final'"],
                 "plan": ["записать файл"]},
                {"thought": "Пишу.", "status": "act",
                 "actions": [{"name": "write_file", "args": {"path": "hello.txt", "content": "final"}}]},
                {"thought": "Готово.", "status": "final", "outcome": "verified",
                 "final_answer": "готово", "lesson": "root"},
            ]
            audit = AuditChain(Path(tmp) / "a.jsonl")
            agent = Agent(cfg, MockBrain(script), Governor(cfg, audit), audit)
            result = agent.solve("создай hello.txt со строкой final")
            assert result["outcome"] == "verified", result
            w = json.loads((Path(cfg.data_dir) / "working.json").read_text(encoding="utf-8"))
            assert isinstance(w.get("root_epoch_chain"), list) and w["root_epoch_chain"], \\
                "root epoch chain отсутствует в runtime state"
            assert w.get("root_epoch_chain_pin"), "пин дайджеста корневой истории отсутствует"
            assert w["proof"].get("root_epoch") == 0, \\
                f"proof.root_epoch={w['proof'].get('root_epoch')} — эпоха не вшита"
            assert w["proof"].get("root_fingerprint") == w["root_epoch_chain"][0]["root_fingerprint"], \\
                "отпечаток корня в proof не совпадает с активной эпохой"
            assert w["commit"].get("root_epoch") == 0, "commit-запись без корневой эпохи"
            led = ImmutableKnowledgeLedger(Path(w["_knowledge_ledger_path"]))
            ok, bad = led.verify(); assert ok, f"ledger повреждён at row {bad}"
            rows = [r for r in led._rows() if r.get("event") == "COMMIT"]
            assert rows and rows[0]["payload"].get("root_epoch") == 0, \\
                "ledger COMMIT не несёт корневую эпоху"
            return "e2e: активная корневая эпоха вшита в proof + commit + ledger COMMIT"

    def t_truncated_root_history_blocks_commit() -> str:
        # v3.8.0 N-RT1: verify_history пропускает усечение хвоста (слабая механика
        # ветки), но COMMIT-гейт сверяет пин дайджеста — усечение блокирует COMMIT.
        st={"_cas_version":0,"criteria":["capability:write_file выполнена"],
            "required_capabilities":["write_file"],
            "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"created"}]}
        h=[RootEpochChain.genesis("ROOT-A","t0")]
        h=RootEpochChain.rotate(h,"ROOT-B","t1"); h=RootEpochChain.rotate(h,"ROOT-C","t2")
        # Тампер-сценарий: пин отражает ПОЛНУЮ историю, в состоянии — УСЕЧЁННАЯ
        # ( ровно как атака усечением хвоста); всё ДО компиляции proof'а, чтобы
        # проверить именно корневой гейт, а не CAS.
        st["root_epoch_chain"]=[asdict(e) for e in h[:2]]
        st["root_epoch_chain_pin"]=RootEpochChain.history_digest(h)
        p=ProofCompiler(st).compile(); st["proof"]=asdict(p)
        try:
            ProofCarryingGovernor.commit(st)
        except ProofCarryingCommitError as e:
            assert "ROOT TRUST" in str(e), str(e)
            return "усечение корневой истории ловится пином и блокирует COMMIT"
        raise AssertionError("truncated root history accepted by COMMIT")

    def t_revoked_root_blocks_commit() -> str:
        # v3.8.0 N-RT4 e2e: отозванный корень запрещает COMMIT; RootTrustError
        # конвертируется в ProofCarryingCommitError (контракт исключений цел).
        st={"_cas_version":0,"criteria":["capability:write_file выполнена"],
            "required_capabilities":["write_file"],
            "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"created"}]}
        h=[RootEpochChain.genesis("ROOT-A","t0")]
        h=RootEpochChain.revoke_current(h)
        st["root_epoch_chain"]=[asdict(e) for e in h]
        st["root_epoch_chain_pin"]=RootEpochChain.history_digest(h)
        p=ProofCompiler(st).compile(); st["proof"]=asdict(p)
        try:
            ProofCarryingGovernor.commit(st)
        except ProofCarryingCommitError as e:
            assert "ROOT TRUST" in str(e) and "no active root" in str(e), str(e)
            return "отозванный корень блокирует COMMIT в контракте исключений"
        raise AssertionError("revoked root accepted by COMMIT")

    def t_double_revoke_and_revoked_rotation_rejected() -> str:
        # v3.8.0 N-RT2: ветка-источник принимала оба молча.
        h=[RootEpochChain.genesis("A","t0")]
        h1=RootEpochChain.revoke_current(h)
        try: RootEpochChain.revoke_current(h1)
        except RootTrustError: pass
        else: raise AssertionError("double revoke accepted")
        try: RootEpochChain.rotate(h1,"B","t1")
        except RootTrustError: pass
        else: raise AssertionError("rotation from revoked accepted")
        return "двойной revoke и ротация от отозванного корня отклоняются"

    def t_replay_root_epoch_rollback_rejected() -> str:
        # v3.8.0: журнал не может содержать откат корневой эпохи.
        led=ImmutableKnowledgeLedger(Path(tempfile.mkdtemp())/"k.jsonl")
        led.append("COMMIT",{"proof_id":"proof:E1","root_epoch":1,"root_fingerprint":"f1"})
        led.append("COMMIT",{"proof_id":"proof:E0","root_epoch":0,"root_fingerprint":"f0"})
        try: led.replay()
        except KnowledgeLedgerError as e:
            assert "root epoch rollback" in str(e), str(e)
            return "replay отклоняет откат корневой эпохи (форк истории)"
        raise AssertionError("root epoch rollback accepted in replay")

    def t_historical_epoch_validation() -> str:
        # Двухконтурная политика: replay/аудит валидирует исторические эпохи,
        # но отозванная/неизвестная эпоха отклоняется.
        h=[RootEpochChain.genesis("A","t0")]; h=RootEpochChain.rotate(h,"B","t1")
        assert RootEpochChain.validate_epoch(h,0,h[0].root_fingerprint)
        try: RootEpochChain.validate_epoch(h,7,h[1].root_fingerprint)
        except RootTrustError: pass
        else: raise AssertionError("unknown epoch accepted")
        hr=RootEpochChain.revoke_current(h)
        try: RootEpochChain.validate_epoch(hr,1,hr[1].root_fingerprint)
        except RootTrustError: pass
        else: raise AssertionError("revoked epoch accepted")
        return "историческая валидация: старая эпоха валидна, неизвестная/отозванная отклонены"

    def t_rt_valid_rotation() -> str:
        h=[RootEpochChain.genesis("ROOT-A","2026-01-01T00:00:00Z")]
        h=RootEpochChain.rotate(h,"ROOT-B","2026-02-01T00:00:00Z")
        RootEpochChain.verify_history(h); assert h[-1].epoch==1
        return "port T94: валидная ротация принимается"

    def t_rt_epoch_rollback_checkpoint() -> str:
        h=[RootEpochChain.genesis("A","t0")]; h=RootEpochChain.rotate(h,"B","t1")
        try: RootEpochChain.validate_checkpoint_active(h,0,h[0].root_fingerprint)
        except RootTrustError: return "port T95: чекпоинт прошлой эпохи против активного контура отклонён"
        raise AssertionError("old epoch accepted")

    def t_rt_old_root_resurrection() -> str:
        h=[RootEpochChain.genesis("A","t0")]; h=RootEpochChain.rotate(h,"B","t1")
        e=RootEpoch(2,h[0].root_fingerprint,h[-1].root_fingerprint,"t2",
                    RootEpochChain.authorization_hash(2,h[0].root_fingerprint,h[-1].root_fingerprint,"t2"))
        try: RootEpochChain.verify_history(h+[e])
        except RootTrustError: return "port T96: воскресение старого корня отклонено"
        raise AssertionError("old root resurrected")

    def t_rt_truncation_pin_required() -> str:
        # УСИЛЕНО против ветки-источника: там тест проверял лишь «digest differs»,
        # а verify_history ПРИНИМАЛ усечённую историю. Здесь: слабая механика
        # демонстрируется, затем пин на production-форме ОТКЛОНЯЕТ усечение.
        h=[RootEpochChain.genesis("A","t0")]; h=RootEpochChain.rotate(h,"B","t1"); h=RootEpochChain.rotate(h,"C","t2")
        trunc=h[:2]
        RootEpochChain.verify_history(trunc)  # слабая механика действительно пропускает
        st={"root_epoch_chain":[asdict(e) for e in trunc],
            "root_epoch_chain_pin":RootEpochChain.history_digest(h)}
        try: RootEpochChain.validate_pinned_state(st)
        except RootTrustError: return "port T97 УСИЛЕН: усечение хвоста отклонено пином на production-форме"
        raise AssertionError("truncation not detected by pin")

    def t_rt_history_fork() -> str:
        h=[RootEpochChain.genesis("A","t0")]; h=RootEpochChain.rotate(h,"B","t1")
        bad=h+[RootEpoch(2,RootEpochChain.fingerprint("C"),RootEpochChain.fingerprint("WRONG"),"t2","0"*64)]
        try: RootEpochChain.verify_history(bad)
        except RootTrustError: return "port T98: форк истории отклонён"
        raise AssertionError("fork accepted")

    def t_rt_domain_confusion() -> str:
        h=[RootEpochChain.genesis("ROOT-A","t0")]
        signing_fp=RootEpochChain.fingerprint("SIGNING-A")
        try: RootEpochChain.validate_checkpoint_active(h,0,signing_fp)
        except RootTrustError: return "port T99: отпечаток подписывающего домена не проходит как корневой"
        raise AssertionError("signing fingerprint accepted as root")

    def t_rt_revoked_no_active() -> str:
        h=[RootEpochChain.genesis("A","t0")]; h=RootEpochChain.rotate(h,"B","t1"); h=RootEpochChain.revoke_current(h)
        try: RootEpochChain.active(h)
        except RootTrustError: return "port T100: у отозванного корня нет активной эпохи"
        raise AssertionError("revoked root remained active")

    def t_rt_auth_tamper() -> str:
        h=[RootEpochChain.genesis("A","t0")]; e=h[0]
        bad=[RootEpoch(e.epoch,e.root_fingerprint,e.parent_fingerprint,e.effective_at,"f"*64,e.revoked)]
        try: RootEpochChain.verify_history(bad)
        except RootTrustError: return "port T101: подмена authorization_hash отклонена"
        raise AssertionError("tamper accepted")

    def t_rt_same_root_rotation() -> str:
        h=[RootEpochChain.genesis("A","t0")]
        try: RootEpochChain.rotate(h,"A","t1")
        except RootTrustError: return "port T102: псевдоротация тем же корнем отклонена"
        raise AssertionError("same root accepted")

    def t_rt_active_fingerprint_mismatch() -> str:
        h=[RootEpochChain.genesis("A","t0")]
        try: RootEpochChain.validate_checkpoint_active(h,0,"0"*64)
        except RootTrustError: return "port T103: чекпоинт с чужим отпечатком отклонён"
        raise AssertionError("wrong fingerprint accepted")

'''

CHECKS = '''    check("T93 trust anchor substitution", t_trust_anchor_detects_substitution)
    check("T121 runtime root epoch bound to COMMIT", t_runtime_root_epoch_bound_to_commit)
    check("T122 truncated root history blocks COMMIT", t_truncated_root_history_blocks_commit)
    check("T123 revoked root blocks COMMIT", t_revoked_root_blocks_commit)
    check("T124 double revoke / revoked rotation rejected", t_double_revoke_and_revoked_rotation_rejected)
    check("T125 replay root-epoch rollback", t_replay_root_epoch_rollback_rejected)
    check("T126 historical epoch validation", t_historical_epoch_validation)
    check("T127 root chain valid rotation (port)", t_rt_valid_rotation)
    check("T128 root epoch rollback checkpoint (port)", t_rt_epoch_rollback_checkpoint)
    check("T129 old-root resurrection (port)", t_rt_old_root_resurrection)
    check("T130 truncation detected via pin (port, усилен)", t_rt_truncation_pin_required)
    check("T131 root-history fork (port)", t_rt_history_fork)
    check("T132 root/signing domain confusion (port)", t_rt_domain_confusion)
    check("T133 revoked root has no active epoch (port)", t_rt_revoked_no_active)
    check("T134 root authorization tamper (port)", t_rt_auth_tamper)
    check("T135 same-root pseudo-rotation (port)", t_rt_same_root_rotation)
    check("T136 active checkpoint fingerprint mismatch (port)", t_rt_active_fingerprint_mismatch)
'''

# Определения функций ОБЯЗАНЫ идти до вызовов check(...) — иначе UnboundLocalError
CHECKS = TEST_DEFS + CHECKS

splice('    check("T93 trust anchor substitution", t_trust_anchor_detects_substitution)',
       CHECKS, "T-checks", mode="replace")

print("splice count:", len(applied))
print("\n".join(f"  [OK] {n}" for n in applied))
DST = Path("/home/z/my-project/download/polymath_agent_v3.8.0.py")
DST.write_text(text, encoding="utf-8")
print("written:", DST, len(text.splitlines()), "lines")
