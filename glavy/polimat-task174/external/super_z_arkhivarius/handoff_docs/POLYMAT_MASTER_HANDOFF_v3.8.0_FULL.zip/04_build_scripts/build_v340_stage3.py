#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Стадия 3 сборки v3.4.0: реставрация тестов-хранителей T67–T72,
новые тесты Dependency-Aware Revocation (T80, T88–T94), шапка, финализация."""
from pathlib import Path

src = Path("/home/z/my-project/scripts/_v340_stage2.py").read_text(encoding="utf-8")

def splice(old: str, new: str, name: str) -> None:
    global src
    n = src.count(old)
    assert n == 1, f"[{name}] якорь встречается {n} раз (ожидался 1)"
    src = src.replace(old, new)
    print(f"  [OK] {name}")

NEW_TESTS = r'''
    # ═══ v3.4.0: реставрация тестов-хранителей T67–T72 (подменённых в ветке v3.3.x) ═══
    def t_dangling_dependency_blocks_verified() -> str:
        st={"criteria":["capability:write_file выполнена","capability:read_file выполнена"],
            "required_capabilities":[],
            "claim_dependencies":{"claim:2":["claim:99"]},
            "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"ok1"},
                      {"step":2,"action":"read_file","ok":True,"kind":"read","obs_brief":"ok2"}],
            "_cas_version":0}
        p=ProofCompiler(st).compile()
        assert p.status=="unknown" and any(":dangling_dependency:claim:99" in x for x in p.unknowns)
        st["proof"]=asdict(p)
        try: ProofCarryingGovernor.commit(st)
        except ProofCarryingCommitError: return "висячая зависимость блокирует VERIFIED и COMMIT"
        raise AssertionError("висячая зависимость пропущена в COMMIT")

    def t_epistemic_blockers_attributed() -> str:
        st={"criteria":["capability:write_file выполнена","capability:read_file выполнена","capability:read_file завершена"],
            "required_capabilities":[],
            "claim_dependencies":{"claim:2":["claim:1"],"claim:3":["claim:2"]},
            "ledger":[{"step":1,"action":"read_file","ok":True,"kind":"read","obs_brief":"ok2"},
                      {"step":2,"action":"read_file","ok":True,"kind":"read","obs_brief":"ok3"}],
            "_cas_version":0}
        p=ProofCompiler(st).compile()
        assert p.status=="unknown"
        assert "claim:1:derivation_missing" in p.unknowns
        assert "claim:2:dependency_unknown" in p.unknowns and "claim:3:dependency_unknown" in p.unknowns
        assert not any(x.startswith("claim:claim:") for x in p.unknowns)
        assert st["epistemic_blockers"]=={"claim:2":["claim:1"],"claim:3":["claim:2","claim:1"]}
        return "blockers атрибутированы по каноническим id"

    def t_blocked_derivation_invalidated() -> str:
        st={"criteria":["capability:write_file выполнена","capability:read_file выполнена"],
            "required_capabilities":[],
            "claim_dependencies":{"claim:2":["claim:1"]},
            "ledger":[{"step":1,"action":"read_file","ok":True,"kind":"read","obs_brief":"ok2"}],
            "_cas_version":0}
        p=ProofCompiler(st).compile()
        assert p.status=="unknown" and "claim:2:dependency_unknown" in p.unknowns
        derivs=[d for d in st["derivations"] if d["claim_id"]=="claim:2"]
        assert derivs and derivs[0]["valid"] is False
        return "деривация зависимого claim инвалидируется при недоказанной предпосылке"

    def t_stale_evidence_blocks_verified() -> str:
        st={"criteria":["capability:write_file выполнена"],"required_capabilities":["write_file"],
            "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"created",
                       "ts":"2020-01-01T00:00:00+00:00"}],
            "_cas_version":0}
        p=ProofCompiler(st).compile()
        assert p.status=="unknown" and "claim:1:stale_evidence" in p.unknowns
        assert not any(x.endswith(":derivation_missing") for x in p.unknowns)
        st["proof"]=asdict(p)
        try: ProofCarryingGovernor.commit(st)
        except ProofCarryingCommitError: pass
        else: raise AssertionError("протухшее evidence прошло COMMIT")
        st2=dict(st); st2.pop("proof"); st2["freshness_max_age_seconds"]=10**9
        assert ProofCompiler(st2).compile().status=="verified"
        return "протухшее evidence блокирует VERIFIED и COMMIT; свежесть — политика"

    def t_dependency_cycle_rejected() -> str:
        st={"criteria":["capability:write_file выполнена","capability:read_file выполнена","capability:read_file завершена"],
            "required_capabilities":[],
            "claim_dependencies":{"claim:1":["claim:2"],"claim:2":["claim:1"],"claim:3":["claim:2"]},
            "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"ok1"},
                      {"step":2,"action":"read_file","ok":True,"kind":"read","obs_brief":"ok2"},
                      {"step":3,"action":"read_file","ok":True,"kind":"read","obs_brief":"ok3"}],
            "_cas_version":0}
        p=ProofCompiler(st).compile()
        assert p.status=="unknown"
        assert "claim:1:dependency_cycle" in p.unknowns and "claim:2:dependency_cycle" in p.unknowns
        assert "claim:3:dependency_unknown" in p.unknowns
        assert st["claim_dependency_cycles"]
        st["proof"]=asdict(p)
        try: ProofCarryingGovernor.commit(st)
        except ProofCarryingCommitError: return "цикл зависимостей отклонён: циркулярная поддержка ≠ proof"
        raise AssertionError("циклический proof прошёл COMMIT")

    def t_governor_tamper_battery() -> str:
        import copy as _copy
        st={"criteria":["capability:write_file выполнена"],"required_capabilities":["write_file"],
            "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"created"}],
            "_cas_version":0}
        p=ProofCompiler(st).compile(); assert p.status=="verified"
        proof_dict=asdict(p)
        def snap():
            s=dict(st); s["proof"]=_copy.deepcopy(proof_dict)
            s["derivations"]=[dict(d) for d in st["derivations"]]
            return s
        ProofCarryingGovernor.commit(snap())
        def m_status(s): s["proof"]["status"]="unknown"
        def m_unknowns(s): s["proof"]["unknowns"]=["injected"]
        def m_pvalid(s): s["derivations"][0]["valid"]=False
        def m_pev(s): s["derivations"][0]["evidence_ids"]=[]
        def m_foreign(s): s["proof"]["claim_ids"]=["claim:9"]
        def m_empty(s): s["proof"]["claim_ids"]=[]
        def m_norule(s): s["proof"].pop("rule")
        def m_noev(s): s["proof"].pop("evidence_ids")
        for name, fn in [("status",m_status),("unknowns",m_unknowns),("premise_valid",m_pvalid),
                         ("premise_evidence",m_pev),("foreign_claim",m_foreign),("empty_claims",m_empty),
                         ("missing_rule",m_norule),("missing_evidence_ids",m_noev)]:
            s=snap(); fn(s)
            try: ProofCarryingGovernor.commit(s)
            except ProofCarryingCommitError: pass
            else: raise AssertionError(f"тамперинг '{name}' прошёл COMMIT")
        return "тампер-батарея: 8 классов мутаций proof отклонены (включая чужие claim_ids)"

    # ═══ v3.4.0: Dependency-Aware Revocation — ArtifactEvidenceEdge ═══
    def t_evidence_artifact_binding() -> str:
        st={"criteria":["capability:write_file выполнена"],"required_capabilities":["write_file"],
            "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"created",
                       "artifact_path":"/tmp/x/art.txt","artifact_sha256":"abc123"}],
            "_cas_version":0}
        p=ProofCompiler(st).compile()
        assert p.artifact_edges.get("evidence:step:1:write_file")=={"/tmp/x/art.txt":"abc123"}
        assert p.status=="verified"
        return "evidence несёт рёбра к состоянию артефактов на момент наблюдения"

    def t_revival_hole_closed() -> str:
        # v3.4.0 ГЛАВНАЯ проба: перекомпиляция после мутации мира не должна позволить
        # старому evidence пережить COMMIT через перезаписанный глобальный пин.
        with tempfile.TemporaryDirectory(prefix="poly_revival_") as td:
            art=Path(td)/"a.txt"; art.write_text("SECRET",encoding="utf-8")
            st={"criteria":["capability:write_file выполнена"],"required_capabilities":["write_file"],
                "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"written",
                           "artifact_path":str(art),"artifact_sha256":sha256_hex(b"SECRET")}],
                "_artifact_paths":[str(art)],"_cas_version":0}
            p1=ProofCompiler(st).compile(); assert p1.status=="verified"
            st["proof"]=asdict(p1); ProofCarryingGovernor.commit(st)
            art.write_text("EVIL",encoding="utf-8")
            st2=dict(st)
            for k in ("proof","commit","epistemic_reconciliation"): st2.pop(k,None)
            p2=ProofCompiler(st2).compile()
            assert p2.status=="verified"
            st2["proof"]=asdict(p2)
            try: ProofCarryingGovernor.commit(st2)
            except ProofCarryingCommitError as e:
                assert "evidence-bound artifact mutation" in str(e), str(e)
                assert st2["revocation"]["reason"]=="evidence_artifact_drift"
                assert st2["revoked_claim_ids"]==["claim:1"]
                assert st2["knowledge_status"]=="REVOKED"
                return "revival-дыра закрыта: перекомпиляция не launder'ит старое evidence"
            raise AssertionError("ревайвл: старое evidence пережило мутацию мира")

    def t_revocation_is_dependency_aware() -> str:
        with tempfile.TemporaryDirectory(prefix="poly_precise_") as td:
            a1=Path(td)/"a1.txt"; a2=Path(td)/"a2.txt"
            a1.write_text("ONE",encoding="utf-8"); a2.write_text("TWO",encoding="utf-8")
            st={"criteria":["capability:write_file выполнена","capability:read_file выполнена"],
                "required_capabilities":[],
                "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"w1",
                           "artifact_path":str(a1),"artifact_sha256":sha256_hex(b"ONE")},
                          {"step":2,"action":"read_file","ok":True,"kind":"read","obs_brief":"r2",
                           "artifact_path":str(a2),"artifact_sha256":sha256_hex(b"TWO")}],
                "_cas_version":0}
            p=ProofCompiler(st).compile(); assert p.status=="verified"
            st["proof"]=asdict(p); ProofCarryingGovernor.commit(st)
            a2.write_text("MUTATED",encoding="utf-8")
            st2=dict(st)
            for k in ("proof","commit","epistemic_reconciliation"): st2.pop(k,None)
            p2=ProofCompiler(st2).compile(); st2["proof"]=asdict(p2)
            try: ProofCarryingGovernor.commit(st2)
            except ProofCarryingCommitError: pass
            else: raise AssertionError("мутация a2 не заблокирована")
            assert st2["revocation"]["evidence_ids"]==["evidence:step:2:read_file"], st2["revocation"]
            assert st2["revoked_claim_ids"]==["claim:2"], st2["revocation"]
            assert "evidence:step:1:write_file" not in st2["revocation"]["evidence_ids"]
            return "каскад точечный: отозвано только знание, связанное с изменённым артефактом"

    def t_post_commit_drift_audit() -> str:
        with tempfile.TemporaryDirectory(prefix="poly_drift_") as td:
            art=Path(td)/"d.txt"; art.write_text("V1",encoding="utf-8")
            st={"criteria":["capability:write_file выполнена"],"required_capabilities":["write_file"],
                "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"w",
                           "artifact_path":str(art),"artifact_sha256":sha256_hex(b"V1")}],
                "_artifact_paths":[str(art)],"_cas_version":0}
            p=ProofCompiler(st).compile(); st["proof"]=asdict(p)
            ProofCarryingGovernor.commit(st)
            assert KnowledgeAuditor.audit(st)["status"]=="VALID"
            art.write_text("V2",encoding="utf-8")
            rep=KnowledgeAuditor.audit(st)
            assert rep["status"]=="STALE" and rep["drift"], rep
            assert st["knowledge_status"]=="STALE" and st["knowledge_drift"]["drift"]
            art.write_text("V1",encoding="utf-8")
            assert KnowledgeAuditor.audit(st)["status"]=="VALID"
            assert st["knowledge_status"]=="VALID"
            return "дрейф мира ПОСЛЕ коммита обнаруживается аудитом (STALE), восстановление снимает"

    def t_revocation_resolution_on_recommit() -> str:
        with tempfile.TemporaryDirectory(prefix="poly_res_") as td:
            art=Path(td)/"r.txt"; art.write_text("ORIGINAL",encoding="utf-8")
            st={"criteria":["capability:write_file выполнена"],"required_capabilities":["write_file"],
                "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"w",
                           "artifact_path":str(art),"artifact_sha256":sha256_hex(b"ORIGINAL")}],
                "_artifact_paths":[str(art)],"_cas_version":0}
            p=ProofCompiler(st).compile(); st["proof"]=asdict(p)
            ProofCarryingGovernor.commit(st)
            art.write_text("MUTATED",encoding="utf-8")
            st2=dict(st)
            for k in ("proof","commit","epistemic_reconciliation"): st2.pop(k,None)
            p2=ProofCompiler(st2).compile(); st2["proof"]=asdict(p2)
            try: ProofCarryingGovernor.commit(st2)
            except ProofCarryingCommitError: pass
            else: raise AssertionError("мутация не заблокирована")
            assert st2["revocation"]["status"]=="REVOKED"
            art.write_text("ORIGINAL",encoding="utf-8")
            st3=dict(st2)
            for k in ("proof","commit","epistemic_reconciliation"): st3.pop(k,None)
            p3=ProofCompiler(st3).compile(); st3["proof"]=asdict(p3)
            ProofCarryingGovernor.commit(st3)
            assert st3["commit"]["status"]=="committed"
            assert st3["revocation"]["status"]=="RESOLVED", st3["revocation"]
            assert len(st3["revocation_history"])==1
            assert st3["knowledge_status"]=="VALID"
            return "успешный re-COMMIT закрывает REVOKED-запись (RESOLVED + история + VALID)"

    def t_closure_error_inside_commit_contract() -> str:
        assert issubclass(ProofClosureError, ProofCarryingCommitError)
        st={"criteria":["capability:write_file выполнена"],"required_capabilities":["write_file"],
            "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"created"}],
            "_cas_version":0}
        p=ProofCompiler(st).compile(); assert p.status=="verified"
        st["proof"]=asdict(p); st["proof"]["claim_ids"]=["claim:9"]
        try: ProofCarryingGovernor.commit(st)
        except ProofCarryingCommitError as e:
            assert isinstance(e, ProofClosureError), type(e)
            return "отказ замыкания остаётся внутри runtime-контракта COMMIT (ProofClosureError ⊂ ProofCarryingCommitError)"
        raise AssertionError("чужой claim_id прошёл замыкание")

    def t_ledger_contradiction_contested() -> str:
        st={"criteria":["capability:write_file выполнена"],"required_capabilities":["write_file"],
            "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"created"},
                      {"step":2,"action":"(verify-fail)","ok":False,"kind":"verify",
                       "obs_brief":"VERIFIED ОТКЛОНЁН Контролёром: критерии не подтверждены ни одним успешным наблюдением в журнале: capability:write_file выполнена"}],
            "_cas_version":0}
        p=ProofCompiler(st).compile()
        assert p.status=="verified"
        st["proof"]=asdict(p)
        try: ProofCarryingGovernor.commit(st)
        except ProofCarryingCommitError as e:
            assert "falsification=CONTESTED" in str(e)
            return "противоречие журнала (verify-fail после evidence) блокирует COMMIT"
        raise AssertionError("противоречие не дошло до falsification-гейта")

    def t_e2e_read_binding_and_drift() -> str:
        # v3.4.0 e2e: production-путь биндит read-наблюдения; мутация файла ПОСЛЕ
        # чтения инвалидирует знание (revival-дыра закрыта на живом контуре).
        with tempfile.TemporaryDirectory() as tmp:
            cfg, ws = _fresh_cfg(tmp)
            Path(ws).mkdir(parents=True, exist_ok=True)
            (Path(ws)/"data.txt").write_text("ORIGINAL",encoding="utf-8")
            script=[
                {"thought": "План: проверить и прочитать артефакт.", "status": "plan",
                 "success_criteria": ["data.txt содержит 'ORIGINAL'"],
                 "plan": ["статистика файла", "прочитать data.txt"]},
                {"thought": "Статистика data.txt.", "status": "act",
                 "actions": [{"name": "stat_path", "args": {"path": "data.txt"}}]},
                {"thought": "Читаю data.txt.", "status": "act",
                 "actions": [{"name": "read_file", "args": {"path": "data.txt"}}]},
                {"thought": "Содержимое сверено.", "status": "final", "outcome": "verified",
                 "final_answer": "data.txt прочитан", "lesson": "read-биндинг"},
            ]
            audit = AuditChain(Path(tmp) / "a.jsonl")
            agent = Agent(cfg, MockBrain(script), Governor(cfg, audit), audit)
            result = agent.solve("прочитай data.txt и подтверди содержимое")
            assert result["outcome"] == "verified", result
            w = json.loads((Path(cfg.data_dir) / "working.json").read_text(encoding="utf-8"))
            rrows=[r for r in w.get("ledger",[]) if r.get("action")=="read_file" and r.get("ok")]
            assert rrows and rrows[-1].get("artifact_path"), "read-наблюдение не получило рёбер к артефакту"
            assert w["proof"]["artifact_edges"], "proof не содержит evidence-рёбер к артефактам"
            assert w["commit"]["status"]=="committed"
            (Path(ws)/"data.txt").write_text("EVIL",encoding="utf-8")
            st=dict(w)
            for k in ("proof","commit","epistemic_reconciliation"): st.pop(k,None)
            p2=ProofCompiler(st).compile(); st["proof"]=asdict(p2)
            try: ProofCarryingGovernor.commit(st)
            except ProofCarryingCommitError as e:
                assert "evidence-bound artifact mutation" in str(e), str(e)
                return "e2e: read-evidence биндится; мутация файла после чтения блокирует COMMIT"
            raise AssertionError("read-evidence не защищён ревокацией")

'''

# ─── SP-21: T76 кодировал старую семантику (старое evidence = derivation_missing);
# v3.4.0 R-D1 различает Stale ≠ Unknown — ассершн усилен, не ослаблен ────────
splice(
'''        p=ProofCompiler(st).compile()
        assert p.status=="unknown" and any(x.endswith(":derivation_missing") for x in p.unknowns)
        return "старое evidence не закрывает claim"
''',
'''        p=ProofCompiler(st).compile()
        assert p.status=="unknown" and any(x.endswith(":stale_evidence") for x in p.unknowns)
        assert not any(x.endswith(":derivation_missing") for x in p.unknowns)
        return "старое evidence не закрывает claim (Stale ≠ Unknown)"
''',
"SP-21 T76 stale semantics")

splice('    check("T61 typed rule matching producer", t_typed_rule_accepts_matching_producer)',
       '    check("T61 typed rule matching producer", t_typed_rule_accepts_matching_producer)\n' + NEW_TESTS +
'''    check("T67 dangling dependency blocks verified", t_dangling_dependency_blocks_verified)
    check("T68 epistemic blockers attribution", t_epistemic_blockers_attributed)
    check("T69 blocked derivation invalidated", t_blocked_derivation_invalidated)
    check("T70 stale evidence blocks verified", t_stale_evidence_blocks_verified)
    check("T71 dependency cycle rejected", t_dependency_cycle_rejected)
    check("T72 governor tamper battery", t_governor_tamper_battery)
    check("T80 evidence artifact binding", t_evidence_artifact_binding)
    check("T88 revival hole closed", t_revival_hole_closed)
    check("T89 revocation is dependency aware", t_revocation_is_dependency_aware)
    check("T90 post commit drift audit", t_post_commit_drift_audit)
    check("T91 revocation resolution on recommit", t_revocation_resolution_on_recommit)
    check("T92 closure error inside commit contract", t_closure_error_inside_commit_contract)
    check("T93 ledger contradiction contested", t_ledger_contradiction_contested)
    check("T94 e2e read binding and drift", t_e2e_read_binding_and_drift)''',
       "SP-19 tests+checks")

# ─── SP-20: шапка-версия ─────────────────────────────────────────────────────
splice(
"» + v3.3.2 CAS/STATE SEPARATION + DEPENDENCY/FRESHNESS + ARTIFACT BINDING (",
"» + v3.3.2 CAS/STATE SEPARATION + DEPENDENCY/FRESHNESS + ARTIFACT BINDING + v3.4.0 DEPENDENCY-AWARE REVOCATION/ARTIFACT EVIDENCE EDGES/REVIVAL GATE (",
"SP-20 header")

DST = Path("/home/z/my-project/download/polymath_agent_v3.4.0.py")
DST.write_text(src, encoding="utf-8")
print(f"Финал записан: {DST} ({len(src.splitlines())} строк)")
