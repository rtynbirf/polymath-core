#!/usr/bin/env python3
"""
build_v380.py — сборка polymath_agent_v3.8.0 «ROOT EPOCH CHAIN WIRING».

База: download/polymath_agent_v3.7.0.py (5064 строк, 114/114).
Источник: ветка JOHNSON v3.6.0 ROOT_TRUST (0a950025…), слой RootEpoch.

Синтез без отбрасывания:
  * Порт RootEpoch-истории (genesis/rotate/revoke/verify/digest) ветки ROOT_TRUST.
  * N-RT4: RootTrustError ∈ KnowledgeLedgerError (в ветке-источнике — Exception,
    выпадал из ledger-контракта исключений).
  * N-RT2: revoke_current от уже отозванного корня ОТКЛОНЯЕТСЯ (ветка принимала молча).
  * N-RT1: пин дайджеста истории обязателен на production-пути
    (validate_pinned_state); усечение хвоста, которое verify_history пропускает,
    ловится пином. Тест ветки T97 проверял лишь «digest differs» — маскировка.
  * N-RT3: слой вшит в COMMIT-гейт (ProofCarryingGovernor.commit): ROOT EPOCH CHAIN
    → Proof → CAS → Revocation → Reconciliation → COMMIT становится реальной дугой;
    активная эпоха вшивается в ProofObject, state["commit"] и ledger-COMMIT-запись.
  * replay: откат корневой эпохи в журнале отклоняется (root epoch rollback).
  * Ленивый бутстрап цепи для состояний вне runtime (unit-тесты/батареи) —
    инвариант «нет COMMIT без валидной активной корневой эпохи под пином»
    выполняется универсально, не ломая ни одного существующего теста.
  * Тесты: T121–T126 новые + T127–T136 порт проб ветки (усилен T130 truncation).
"""
from pathlib import Path
import re
import sys

SRC = Path("/home/z/my-project/download/polymath_agent_v3.7.0.py")
DST = Path("/home/z/my-project/download/polymath_agent_v3.8.0.py")

text = SRC.read_text(encoding="utf-8")
applied = []


def splice(anchor: str, replacement: str, name: str, count: int = 1, mode: str = "replace"):
    global text
    found = text.count(anchor)
    assert found == count, f"[{name}] anchor found {found} times (expected {count}):\n{anchor[:120]}"
    if mode == "replace":
        text = text.replace(anchor, replacement)
    elif mode == "after":
        text = text.replace(anchor, anchor + replacement)
    elif mode == "before":
        text = text.replace(anchor, replacement + anchor)
    applied.append(name)


# ─────────────────────────────────────────────────────────────────────────────
# S1: заголовок
# ─────────────────────────────────────────────────────────────────────────────
splice("+ v3.6.0 TRUST-DOMAIN KEY EPOCHS (восстановлено из базы v2",
       "+ v3.6.0 TRUST-DOMAIN KEY EPOCHS + v3.8.0 ROOT EPOCH CHAIN (восстановлено из базы v2",
       "S1 header")

# ─────────────────────────────────────────────────────────────────────────────
# S2: классы RootTrustError / RootEpoch / RootEpochChain — после hmac_compare
# ─────────────────────────────────────────────────────────────────────────────
HMAC_ANCHOR = """def hmac_compare(a: str, b: str) -> bool:
    import hmac
    return hmac.compare_digest(a, b)
"""

ROOT_CHAIN_CODE = '''

# ═══════════════════════════════════════════════════════════════════════════════
# v3.8.0 — ROOT EPOCH CHAIN (порт ветки JOHNSON v3.6.0 ROOT_TRUST, 0a950025…;
# закрыты N-RT1..N-RT4). Append-only история корневых эпох: genesis → rotate →
# revoke. ROOT → Proof → CAS → Revocation → Reconciliation → COMMIT — реальная
# дуга: активная эпоха вшивается в ProofObject и ledger-COMMIT (N-RT3).
# ═══════════════════════════════════════════════════════════════════════════════
class RootTrustError(KnowledgeLedgerError):
    """v3.8.0 N-RT4: нарушение инвариантов корневой истории — ЧАСТЬ ledger-контракта
    исключений (в ветке-источнике RootTrustError(Exception) выпадал из контракта:
    отказ COMMIT вырывался бы из except-обвязки runtime вместо честного verify-fail)."""


@dataclass(frozen=True)
class RootEpoch:
    epoch: int
    root_fingerprint: str
    parent_fingerprint: Optional[str]
    effective_at: str
    authorization_hash: str
    revoked: bool = False


class RootEpochChain:
    """Детерминированная append-only история корневых эпох.

    Порт ветки JOHNSON v3.6.0 ROOT_TRUST с закрытыми дефектами:
      N-RT1 — усечение хвоста истории verify_history НЕ видит (e.epoch==i сходится);
              обнаружимо ТОЛЬКО внешним пином дайджеста. Пин обязателен на
              production-пути: validate_pinned_state() в COMMIT-гейте. Тест ветки
              T97 проверял лишь «digest differs» — усечённая история ПРИНИМАЛАСЬ.
      N-RT2 — повторный revoke того же корня отклоняется (ветка принимала молча).
      N-RT3 — слой вшит в COMMIT (раньше: класс + selftest, ноль production-вызовов).
      N-RT4 — RootTrustError наследник KnowledgeLedgerError (контракт исключений цел).
    Политика валидации чекпоинтов — двухконтурная:
      validate_checkpoint_active — строгий контур НОВЫХ коммитов (только активная
      эпоха; ротация отклоняет ссылки на прошлые эпохи);
      validate_epoch — исторический контур аудита/replay (эпоха валидна, если
      существует в истории, не отозвана и отпечаток совпадает).
    """
    DOMAIN = "JOHNSON:ROOT-EPOCH:v1"

    @staticmethod
    def fingerprint(public_material: str) -> str:
        return sha256_hex(public_material.encode("utf-8"))

    @classmethod
    def authorization_hash(cls, epoch: int, root_fp: str, parent_fp: Optional[str], effective_at: str) -> str:
        return sha256_hex(canonical_json({"domain": cls.DOMAIN, "epoch": int(epoch),
                                          "root_fingerprint": root_fp,
                                          "parent_fingerprint": parent_fp,
                                          "effective_at": effective_at}))

    @classmethod
    def genesis(cls, public_material: str, effective_at: str) -> RootEpoch:
        fp = cls.fingerprint(public_material)
        return RootEpoch(0, fp, None, effective_at,
                         cls.authorization_hash(0, fp, None, effective_at))

    @classmethod
    def rotate(cls, history: List[RootEpoch], new_public_material: str, effective_at: str) -> List[RootEpoch]:
        cls.verify_history(history)
        current = history[-1]
        if current.revoked:
            raise RootTrustError("cannot rotate from revoked root")
        fp = cls.fingerprint(new_public_material)
        if fp == current.root_fingerprint:
            raise RootTrustError("root rotation must change root fingerprint")
        out = list(history)
        out.append(RootEpoch(current.epoch + 1, fp, current.root_fingerprint, effective_at,
                             cls.authorization_hash(current.epoch + 1, fp, current.root_fingerprint, effective_at)))
        cls.verify_history(out)
        return out

    @classmethod
    def revoke_current(cls, history: List[RootEpoch]) -> List[RootEpoch]:
        cls.verify_history(history)
        current = history[-1]
        # v3.8.0 N-RT2: повторный revoke — ошибка, а не молчаливое принятие
        if current.revoked:
            raise RootTrustError("root epoch already revoked")
        out = list(history)
        out[-1] = RootEpoch(current.epoch, current.root_fingerprint, current.parent_fingerprint,
                            current.effective_at, current.authorization_hash, True)
        return out

    @classmethod
    def verify_history(cls, history: List[RootEpoch]) -> bool:
        if not history:
            raise RootTrustError("empty root history")
        seen = set()
        for i, e in enumerate(history):
            if e.epoch != i:
                raise RootTrustError("root epoch rollback or truncation detected")
            if e.root_fingerprint in seen:
                raise RootTrustError("root fingerprint reuse/resurrection detected")
            seen.add(e.root_fingerprint)
            if e.authorization_hash != cls.authorization_hash(e.epoch, e.root_fingerprint,
                                                              e.parent_fingerprint, e.effective_at):
                raise RootTrustError("root authorization tampering detected")
            if i == 0:
                if e.parent_fingerprint is not None:
                    raise RootTrustError("genesis root has a parent")
            else:
                prev = history[i - 1]
                if e.parent_fingerprint != prev.root_fingerprint:
                    raise RootTrustError("root-history fork or parent mismatch")
                if prev.revoked:
                    raise RootTrustError("rotation from revoked root")
        return True

    @classmethod
    def active(cls, history: List[RootEpoch]) -> RootEpoch:
        cls.verify_history(history)
        if history[-1].revoked:
            raise RootTrustError("no active root")
        return history[-1]

    @classmethod
    def history_digest(cls, history: List[RootEpoch]) -> str:
        cls.verify_history(history)
        return sha256_hex(canonical_json([asdict(e) for e in history]))

    # ── v3.8.0: контур состояния задачи ─────────────────────────────────────

    @staticmethod
    def _hist_from_state(state: Dict[str, Any]) -> List[RootEpoch]:
        raw = state.get("root_epoch_chain")
        if not isinstance(raw, list) or not raw:
            raise RootTrustError("root epoch chain missing from state")
        out: List[RootEpoch] = []
        for d in raw:
            if not isinstance(d, dict) or not {"epoch", "root_fingerprint", "parent_fingerprint",
                                               "effective_at", "authorization_hash"}.issubset(d):
                raise RootTrustError("malformed root epoch entry")
            out.append(RootEpoch(int(d["epoch"]), d["root_fingerprint"], d.get("parent_fingerprint"),
                                 d["effective_at"], d["authorization_hash"], bool(d.get("revoked", False))))
        return out

    @classmethod
    def pin_state(cls, state: Dict[str, Any]) -> str:
        hist = cls._hist_from_state(state)
        pin = cls.history_digest(hist)
        state["root_epoch_chain_pin"] = pin
        return pin

    @classmethod
    def validate_pinned_state(cls, state: Dict[str, Any]) -> bool:
        """v3.8.0 N-RT1: подмена/усечение истории обнаружимы сравнением с пином.
        Без пина verify_history пропускает усечение хвоста (weak mechanic ветки)."""
        hist = cls._hist_from_state(state)
        cls.verify_history(hist)
        pin = state.get("root_epoch_chain_pin")
        if not isinstance(pin, str) or not pin:
            raise RootTrustError("root epoch chain pin missing")
        if not hmac_compare(cls.history_digest(hist), pin):
            raise RootTrustError("root epoch chain tamper/truncation detected (digest pin mismatch)")
        return True

    @classmethod
    def validate_checkpoint_active(cls, history: List[RootEpoch], root_epoch: int, root_fingerprint: str) -> bool:
        """Строгий контур НОВЫХ коммитов: только активная эпоха."""
        act = cls.active(history)
        if int(root_epoch) != act.epoch:
            raise RootTrustError("checkpoint references non-active root epoch")
        if not hmac_compare(root_fingerprint, act.root_fingerprint):
            raise RootTrustError("checkpoint root fingerprint mismatch")
        return True

    @classmethod
    def validate_epoch(cls, history: List[RootEpoch], epoch: int, root_fingerprint: str) -> bool:
        """Исторический контур аудита/replay: эпоха валидна, если существует в
        истории, не отозвана и отпечаток совпадает (ротация не инвалидизирует
        старые записи ретроактивно; отозванный корень теряет силу консервативно)."""
        cls.verify_history(history)
        for e in history:
            if e.epoch == int(epoch):
                if e.revoked:
                    raise RootTrustError("checkpoint references revoked root epoch")
                if not hmac_compare(e.root_fingerprint, root_fingerprint):
                    raise RootTrustError("checkpoint root fingerprint mismatch")
                return True
        raise RootTrustError("checkpoint references unknown root epoch")

    @classmethod
    def require_active_from_state(cls, state: Dict[str, Any]) -> RootEpoch:
        """COMMIT-гейт: цепь обязана существовать, быть целой под пином и иметь
        активную (не отозванную) корневую эпоху. Ленивый бутстрап для состояний
        вне runtime (unit/батареи) сохраняет инвариант универсально; runtime
        (Agent.solve) создаёт цепь явно на старте задачи."""
        raw = state.get("root_epoch_chain")
        if not isinstance(raw, list) or not raw:
            hist = [cls.genesis("JOHNSON-ROOT:bootstrap", now_iso())]
            state["root_epoch_chain"] = [asdict(e) for e in hist]
            state["root_epoch_chain_pin"] = cls.history_digest(hist)
        cls.validate_pinned_state(state)
        return cls.active(cls._hist_from_state(state))


'''

splice(HMAC_ANCHOR, HMAC_ANCHOR + ROOT_CHAIN_CODE, "S2 root chain classes", mode="replace")

# ─────────────────────────────────────────────────────────────────────────────
# S3: поля ProofObject
# ─────────────────────────────────────────────────────────────────────────────
splice('    artifact_edges: Dict[str, Dict[str, str]] = field(default_factory=dict)  # v3.7.0: evidence → {путь: хеш наблюдения}',
       '''    artifact_edges: Dict[str, Dict[str, str]] = field(default_factory=dict)  # v3.7.0: evidence → {путь: хеш наблюдения}
    root_epoch: int = -1            # v3.8.0: активная корневая эпоха в момент COMMIT (N-RT3)
    root_fingerprint: str = ""      # v3.8.0: отпечаток активного корня в момент COMMIT''',
       "S3 proof fields")

# ─────────────────────────────────────────────────────────────────────────────
# S4: COMMIT-гейт — ROOT TRUST перед материализацией commit-записи
# ─────────────────────────────────────────────────────────────────────────────
GATE = '''        # v3.8.0 ROOT TRUST GATE (закрытие N-RT3 «мёртвый слой»): дуга
        # ROOT EPOCH CHAIN → Proof → CAS → Revocation → Reconciliation → COMMIT
        # становится реальной. История корневых эпох сверяется с пином дайджеста
        # (усечение/подмена блокируются — N-RT1), активная эпоха вшивается в
        # ProofObject, state["proof"], commit-запись и ledger. Отозванный/пустой
        # корень запрещает COMMIT; RootTrustError ∈ KnowledgeLedgerError
        # конвертируется в честный verify-fail контракта (N-RT4).
        try:
            _root_active = RootEpochChain.require_active_from_state(state)
        except RootTrustError as _rte:
            raise ProofCarryingCommitError(f"COMMIT: ROOT TRUST: {_rte}") from _rte
        proof.root_epoch = _root_active.epoch
        proof.root_fingerprint = _root_active.root_fingerprint
        if isinstance(state.get("proof"), dict):
            state["proof"]["root_epoch"] = _root_active.epoch
            state["proof"]["root_fingerprint"] = _root_active.root_fingerprint

'''
splice('        state["epistemic_reconciliation"]=reconciliation', GATE + '        state["epistemic_reconciliation"]=reconciliation',
       "S4 commit gate", mode="replace")

# ─────────────────────────────────────────────────────────────────────────────
# S5: commit-запись несёт корневую эпоху
# ─────────────────────────────────────────────────────────────────────────────
splice('        state["commit"]={"status":"committed","proof_id":proof.id,"committed_at":now_iso(),"world_verdict":reconciliation["world_verdict"]}',
       '        state["commit"]={"status":"committed","proof_id":proof.id,"committed_at":now_iso(),"world_verdict":reconciliation["world_verdict"],"root_epoch":proof.root_epoch,"root_fingerprint":proof.root_fingerprint}',
       "S5 commit record")

# ─────────────────────────────────────────────────────────────────────────────
# S6: ledger COMMIT-запись несёт корневую эпоху
# ─────────────────────────────────────────────────────────────────────────────
splice('''            ImmutableKnowledgeLedger(Path(ledger_path)).append("COMMIT", {
                "proof_id": proof.id,
                "claim_ids": list(proof.claim_ids),
                "evidence_ids": list(proof.evidence_ids),
                "artifact_hashes": dict(proof.artifact_hashes),
                "proof_hash": sha256_hex(canonical_json(asdict(proof))),
            })''',
       '''            ImmutableKnowledgeLedger(Path(ledger_path)).append("COMMIT", {
                "proof_id": proof.id,
                "claim_ids": list(proof.claim_ids),
                "evidence_ids": list(proof.evidence_ids),
                "artifact_hashes": dict(proof.artifact_hashes),
                "root_epoch": proof.root_epoch,
                "root_fingerprint": proof.root_fingerprint,
                "proof_hash": sha256_hex(canonical_json(asdict(proof))),
            })''',
       "S6 ledger payload")

# ─────────────────────────────────────────────────────────────────────────────
# S7: генезис цепи в runtime (solve) — рядом с knowledge-путями v3.7.0
# ─────────────────────────────────────────────────────────────────────────────
splice('            state["_knowledge_revocation_index_path"]=str(_know_dir/f"{task_id}.revocation_index.jsonl")',
       '''            state["_knowledge_revocation_index_path"]=str(_know_dir/f"{task_id}.revocation_index.jsonl")
            # v3.8.0 N-RT3: корневая цепь эпох живёт в состоянии задачи с пином
            # дайджеста; COMMIT сверяет её на каждом такте (гейт в governor.commit).
            if not state.get("root_epoch_chain"):
                _root_material=state.get("root_public_material") or f"JOHNSON-ROOT:{task_id}"
                _root_hist=[RootEpochChain.genesis(_root_material, now_iso())]
                state["root_epoch_chain"]=[asdict(e) for e in _root_hist]
                state["root_epoch_chain_pin"]=RootEpochChain.history_digest(_root_hist)''',
       "S7 runtime genesis")

# ─────────────────────────────────────────────────────────────────────────────
# S8: replay — контроль отката корневой эпохи
# ─────────────────────────────────────────────────────────────────────────────
splice('        state={"committed":{},"revoked":{},"events":0}',
       '''        state={"committed":{},"revoked":{},"events":0}
        last_root_epoch=-1  # v3.8.0: контроль отката корневой эпохи в журнале''',
       "S8a replay init")

splice('                state["committed"][pid]=dict(payload)',
       '''                _pe=int(payload.get("root_epoch", -1))
                if _pe >= 0:
                    # v3.8.0: COMMIT не может откатывать корневую эпоху — форк истории
                    if _pe < last_root_epoch:
                        raise KnowledgeLedgerError(f"replay fork: root epoch rollback: {pid}")
                    last_root_epoch=_pe
                state["committed"][pid]=dict(payload)''',
       "S8b replay epoch check")

print("splice count:", len(applied))
print("\n".join(f"  [OK] {n}" for n in applied))

DST.write_text(text, encoding="utf-8")
print("written:", DST, len(text.splitlines()), "lines")
