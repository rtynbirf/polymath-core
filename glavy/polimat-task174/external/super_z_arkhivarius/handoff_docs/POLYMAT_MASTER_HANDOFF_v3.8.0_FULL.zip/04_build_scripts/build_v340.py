#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка polymath_agent_v3.4.0 «Dependency-Aware Revocation».

База: upload/polymath_agent_JOHNSON_v3.3.3.py (74/74, свежесть/циклы/CAS/RevocationCascade)
Порты из v3.3.1 (реставрация 5 реставраций + живой falsification):
  R-D1 канонические id + Stale≠Unknown; R-D2 dangling-гейт; R-D3 TMS-инвалидация;
  N-CLM foreign claim ids; N-CLS ProofClosureError⊂ProofCarryingCommitError; N-FALS infer_from_ledger.
Новое v3.4.0:
  ArtifactEvidenceEdge (evidence помнит хеши артефактов В МОМЕНТ наблюдения; write/read/verify);
  RevocationCascade v2 (dependency-aware: ревокация ТОЛЬКО связанного знания);
  detect_evidence_drift/apply_drift (закрытие revival-дыры: перекомпиляция не launder'ит evidence);
  N-RES (успешный COMMIT закрывает REVOKED-запись с историей);
  KnowledgeAuditor (post-commit drift → STALE вне commit-пути).
"""
from pathlib import Path
import sys

SRC = Path("/home/z/my-project/upload/polymath_agent_JOHNSON_v3.3.3.py")
DST = Path("/home/z/my-project/download/polymath_agent_v3.4.0.py")

src = SRC.read_text(encoding="utf-8")

def splice(old: str, new: str, name: str) -> None:
    global src
    n = src.count(old)
    assert n == 1, f"[{name}] якорь встречается {n} раз (ожидался 1)"
    src = src.replace(old, new)
    print(f"  [OK] {name}")

# ─── SP-01: import replace ───────────────────────────────────────────────────
splice(
"from dataclasses import dataclass, field, asdict",
"from dataclasses import dataclass, field, asdict, replace",
"SP-01 import replace")

# ─── SP-02: EvidenceObject.artifact_edges ────────────────────────────────────
splice(
"""    observed_at: str
    valid: bool = True
    producer: str = ""
    integrity_ok: bool = True
""",
"""    observed_at: str
    valid: bool = True
    producer: str = ""
    integrity_ok: bool = True
    artifact_edges: Dict[str, str] = field(default_factory=dict)  # v3.4.0: {artifact_path: hash_на_момент_наблюдения}
""",
"SP-02 EvidenceObject.artifact_edges")

# ─── SP-03: ProofObject.artifact_edges ───────────────────────────────────────
splice(
"""    artifact_hashes: Dict[str, str] = field(default_factory=dict)
    source_state_hash: str = ""
    state_version: int = 0
""",
"""    artifact_hashes: Dict[str, str] = field(default_factory=dict)
    source_state_hash: str = ""
    state_version: int = 0
    artifact_edges: Dict[str, Dict[str, str]] = field(default_factory=dict)  # v3.4.0: evidence → {path: hash_наблюдения}
""",
"SP-03 ProofObject.artifact_edges")

# ─── SP-04: evidence из журнала несёт рёбра ─────────────────────────────────
splice(
"""        for row in state.get("ledger", []):
            if row.get("ok") and row.get("action") not in {"(план)","(verify-fail)"}:
                self.evidence.append(EvidenceObject(
                    id=f"evidence:step:{row.get('step')}:{row.get('action')}",
                    claim_id="",
                    kind=row.get("kind","observation"),
                    source_ref=f"step:{row.get('step')}",
                    content_hash=sha256_hex(row.get("obs_brief","")),
                    observed_at=row.get("ts", now_iso()),
                    producer=row.get("action", ""), integrity_ok=bool(row.get("ok"))))
""",
"""        for row in state.get("ledger", []):
            if row.get("ok") and row.get("action") not in {"(план)","(verify-fail)"}:
                # v3.4.0 ArtifactEvidenceEdge: evidence помнит состояние артефакта
                # В МОМЕНТ наблюдения (если действие имело путь к файлу).
                _edges={}
                _ap=row.get("artifact_path"); _ah=row.get("artifact_sha256")
                if _ap and _ah: _edges[str(_ap)]=str(_ah)
                self.evidence.append(EvidenceObject(
                    id=f"evidence:step:{row.get('step')}:{row.get('action')}",
                    claim_id="",
                    kind=row.get("kind","observation"),
                    source_ref=f"step:{row.get('step')}",
                    content_hash=sha256_hex(row.get("obs_brief","")),
                    observed_at=row.get("ts", now_iso()),
                    producer=row.get("action", ""), integrity_ok=bool(row.get("ok")),
                    artifact_edges=_edges))
""",
"SP-04 evidence artifact binding")

# ─── SP-05: R-D1 канонический id + Stale ≠ Unknown ──────────────────────────
splice(
"""            else:
                unknown.append(f"claim:{c.id}:derivation_missing")
""",
"""            else:
                # v3.4.0 R-D1: Stale ≠ Unknown — протухшее evidence не сливается
                # с отсутствующим; канонический id без двойного префикса.
                any_age=replace(contract, max_age_seconds=None)
                if [e for e in self.evidence if self._matches(c,e,any_age)]:
                    unknown.append(f"{c.id}:stale_evidence")
                else:
                    unknown.append(f"{c.id}:derivation_missing")
""",
"SP-05 R-D1 canonical ids + stale")

# ─── SP-06: ранняя covered удаляется (пересчёт после TMS) ───────────────────
splice(
"""        covered=graph.covered()
        dep_graph=EpistemicDependencyGraph(self.state.get("claim_dependencies", {}))
""",
"""        dep_graph=EpistemicDependencyGraph(self.state.get("claim_dependencies", {}))
""",
"SP-06 remove early covered")

# ─── SP-07: R-D2 dangling + R-D3 TMS ────────────────────────────────────────
splice(
"""        missing_claims={x.split(":derivation_missing",1)[0] for x in unknown if x.endswith(":derivation_missing")}
        propagated=dep_graph.propagate(missing_claims)
        for claim_id in sorted(propagated):
            reason=f"{claim_id}:dependency_unknown"
            if reason not in unknown and claim_id not in covered:
                unknown.append(reason)
""",
"""        claims_by_id={c.id: c for c in self.claims}
        # v3.4.0 R-D2: висячая зависимость — ссылка на claim, которого не существует;
        # узел недоказуем никогда: блокирует себя и всех зависимых (I24).
        for c in self.claims:
            for dep in dep_graph.dependencies.get(c.id, []):
                if dep not in claims_by_id:
                    reason=f"{c.id}:dangling_dependency:{dep}"
                    if reason not in unknown:
                        unknown.append(reason)
        # TMS-распространение: Unknown/Stale/Cycle/Dangling(x) ∧ Depends(y,x) ⇒ ¬Certain(y)
        unproven={x.split(":derivation_missing",1)[0] for x in unknown if x.endswith(":derivation_missing")}
        unproven|={x.split(":dangling_dependency:",1)[0] for x in unknown if ":dangling_dependency:" in x}
        unproven|={x.split(":stale_evidence",1)[0] for x in unknown if x.endswith(":stale_evidence")}
        unproven|={x.split(":dependency_cycle",1)[0] for x in unknown if x.endswith(":dependency_cycle")}
        propagated=dep_graph.propagate(unproven)
        # v3.4.0 R-D3: опровержение основания опрокидывает зависимые узлы —
        # деривация заблокированного claim'а получает valid=False и выбывает из покрытия.
        blocked={c.id for c in self.claims if c.id in propagated}
        for d in graph.derivations:
            if d.claim_id in blocked:
                d.valid=False
        covered=graph.covered()
        for claim_id in sorted(propagated):
            reason=f"{claim_id}:dependency_unknown"
            if reason not in unknown:
                unknown.append(reason)
""",
"SP-07 R-D2 dangling gate + R-D3 TMS")

# ─── SP-08: compile() отдаёт artifact_edges в ProofObject ───────────────────
splice(
"""        return ProofObject(f"proof:{sha256_hex(canonical_json(self.state))[:16]}",status,
                           [c.id for c in self.claims],evidence_ids,
                           self.RULE,unknown,rule_obj.version if rule_obj else "",
                           nodes,edges,evidence_hashes,now_iso(),
                           {e.id:e.observed_at for e in self.evidence if e.id in evidence_ids},
                           artifact_hashes,
                           StateCAS.fingerprint(self.state), int(self.state.get("_cas_version",0)))
""",
"""        artifact_edges={e.id:dict(e.artifact_edges) for e in self.evidence if e.artifact_edges}
        return ProofObject(f"proof:{sha256_hex(canonical_json(self.state))[:16]}",status,
                           [c.id for c in self.claims],evidence_ids,
                           self.RULE,unknown,rule_obj.version if rule_obj else "",
                           nodes,edges,evidence_hashes,now_iso(),
                           {e.id:e.observed_at for e in self.evidence if e.id in evidence_ids},
                           artifact_hashes,
                           StateCAS.fingerprint(self.state), int(self.state.get("_cas_version",0)),
                           artifact_edges)
""",
"SP-08 compile returns artifact_edges")

# ─── SP-09a: N-CLS — ProofCarryingCommitError раньше ProofClosureError ───────
splice(
"""class ProofClosureError(PolicyViolation):
    pass
""",
"""class ProofCarryingCommitError(PolicyViolation):
    \"\"\"COMMIT запрещён, если доказательство не замкнуто или мир ему противоречит.\"\"\"

class ProofClosureError(ProofCarryingCommitError):
    \"\"\"v3.4.0 N-CLS: отказ замыкания — часть runtime-контракта COMMIT
    (ловится except ProofCarryingCommitError, а не рвёт run-loop).\"\"\"
""",
"SP-09a exception hierarchy")

# ─── SP-09b: удалить позднее дублирование класса ─────────────────────────────
splice(
"""class ProofCarryingCommitError(PolicyViolation):
    \"\"\"COMMIT запрещён, если доказательство не замкнуто или мир ему противоречит.\"\"\"

class ProofCarryingGovernor:
""",
"""class ProofCarryingGovernor:
""",
"SP-09b remove duplicate exception class")

# ─── SP-10: N-CLM — чужие claim_ids не проходят замыкание ───────────────────
splice(
"""        if not node_map:
            raise ProofClosureError("PROOF_CLOSURE: empty DAG")
        if any(eid not in proof.evidence_hashes for eid in evidence):
""",
"""        if not node_map:
            raise ProofClosureError("PROOF_CLOSURE: empty DAG")
        # v3.4.0 N-CLM: claim_ids proof'а обязаны ссылаться на claim-узлы того же proof'а —
        # чужие/подменённые id не проходят замыкание (класс тампер-батареи T72).
        node_claims={n.get("claim_id") for n in proof.nodes if isinstance(n,dict) and n.get("kind")=="claim"}
        if any(cid not in node_claims for cid in proof.claim_ids):
            raise ProofClosureError("PROOF_CLOSURE: foreign claim id")
        if any(eid not in proof.evidence_hashes for eid in evidence):
""",
"SP-10 N-CLM foreign claim ids")

print("Часть 1 сплайсов применена.")
Path("/home/z/my-project/scripts/_v340_stage1.py").write_text(src, encoding="utf-8")
print("Стадия 1 сохранена: scripts/_v340_stage1.py")
