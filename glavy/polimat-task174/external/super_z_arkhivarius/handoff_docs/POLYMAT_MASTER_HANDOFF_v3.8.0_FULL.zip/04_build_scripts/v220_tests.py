# -*- coding: utf-8 -*-
"""Блок новых тестов T44–T54 для polymath_agent v2.2.0."""

NEW_TESTS_BLOCK = '''    # ══ v2.2.0: Task Compiler 2.0 (ветка Б) + Proof Gate / Claim Compiler (ветка А) ══
    def t_production_dependency_knowledge() -> str:
        with tempfile.TemporaryDirectory(prefix="poly_t44_") as td:
            cfg,_=_fresh_cfg(td); gov=Governor(cfg, AuditChain(Path(td)/"a.jsonl"), CatalogBridge(""))
            # РОВНО продакшн-путь: CapabilityGraph(gov.registry) как в Agent.__init__
            g=CapabilityGraph(gov.registry)
            assert g.nodes["research_web"]["deps"]==["web_search"], "знание зависимостей не засеяно"
            spec=FormalGoalCompiler().compile_spec("исследуй тему через интернет",gov.registry,CapabilityPlanner(g))
            assert "web_search" in spec.capabilities, "фактический необходимый источник не в плане"
            dag=ActionDAG(spec,g)
            assert dag.nodes["research_web"].depends_on==["web_search"], "depends_on пуст — guard мёртв"
            assert not dag.ready("research_web"), "guard не блокирует до источника"
            dag.start("web_search"); dag.complete("web_search",Observation(True,"net","ok"))
            assert dag.ready("research_web"), "guard не отпускает после источника"
            # эвристика: локальная задача не трактуется как веб-запрос
            base=GoalCompiler().compile("найди файл отчёт",gov.registry)
            assert "research_web" not in base["requested_capabilities"] and "web_search" not in base["requested_capabilities"], \\
                "«найди файл» ложно триггерит веб-контур"
            return "продакшн-DAG получил реальные зависимости; «найди файл» больше не веб-запрос"

    def t_dns_pinning_blocks_rebinding() -> str:
        with tempfile.TemporaryDirectory(prefix="poly_t45_") as td:
            cfg,_=_fresh_cfg(td); gov=Governor(cfg, AuditChain(Path(td)/"a.jsonl"), CatalogBridge(""))
            real_getaddrinfo=socket.getaddrinfo
            HOST="rebind.proof.invalid"
            calls={"n":0}; resolved=[]
            def rebind_getaddrinfo(host,port=None,*a,**kw):
                if host==HOST:
                    calls["n"]+=1
                    ip="93.184.216.34" if calls["n"]==1 else "127.0.0.1"   # rebinding-атака
                    sa=(ip, port if port else 80); resolved.append(sa)
                    return [(socket.AF_INET,socket.SOCK_STREAM,6,"",sa)]
                return real_getaddrinfo(host,*a,**kw)
            dials=[]
            real_create=socket.create_connection
            def spying(address,*a,**kw):
                dials.append(address); return real_create(address,*a,**kw)
            socket.getaddrinfo=rebind_getaddrinfo; socket.create_connection=spying
            try:
                obs, _fp = gov.run("t45",1,"http_get",{"url":f"http://{HOST}:9/x"})
            finally:
                socket.getaddrinfo=real_getaddrinfo; socket.create_connection=real_create
            assert not obs.ok and obs.kind=="policy_denied", f"rebinding должен быть отклонён: {obs.brief(160)}"
            assert len(resolved)==2, f"guard+connect = 2 резолва, фактически {len(resolved)}"
            assert not any(d[0]=="127.0.0.1" for d in dials), \\
                f"DIAL НА 127.0.0.1 СОСТОЯЛСЯ — pinning сломан: {dials}"
            # вариант 2: даже первый резолв приватный — отклонение до всякого соединения
            calls["n"]=0; resolved.clear(); dials.clear()
            socket.getaddrinfo=lambda h,p=None,*a,**kw: ([(socket.AF_INET,socket.SOCK_STREAM,6,"",("10.0.0.5",p or 80))] if h==HOST else real_getaddrinfo(h,*a,**kw))
            try:
                obs2, _fp2 = gov.run("t45",2,"http_get",{"url":f"http://{HOST}:9/x"})
            finally:
                socket.getaddrinfo=real_getaddrinfo
            assert not obs2.ok and obs2.kind=="policy_denied", "приватный резолв обязан быть отклонён"
            assert not dials, "соединения не должно быть вовсе"
            return "DNS-pinning: dial только по валидированному IP; rebinding на 127.0.0.1 закрыт"

    def t_dataflow_compile_and_guard() -> str:
        df=DataFlowGraph()
        df.note_producer("execute_python",1); df.link_consumer("write_file")
        assert any(e["src"]=="execute_python" and e["dst"]=="write_file" and e["via"]=="$last_output"
                   for e in df.edges), "producer→consumer ребро не скомпилировано"
        df2=DataFlowGraph(); df2.note_producer("write_file",1)
        try:
            df2.link_consumer("write_file"); self_edge=False
        except PolicyViolation: self_edge=True
        assert self_edge, "self-ребро (потребление собственного вывода) должно быть запрещено"
        snap=df.snapshot(); df3=DataFlowGraph(); df3.restore_snapshot(snap)
        assert df3.edges==df.edges and df3.nodes==df.nodes, "snapshot roundtrip сломан"
        df4=DataFlowGraph()
        try:
            df4.edges=[{"src":"a","dst":"b","via":"x","producer_step":1},
                       {"src":"b","dst":"a","via":"x","producer_step":2}]
            df4._assert_acyclic(); cyclic=False
        except PolicyViolation: cyclic=True
        assert cyclic, "цикл в dataflow должен быть обнаружен"
        return "dataflow: ребро producer→consumer; self-ребро и цикл запрещены; roundtrip точен"

    def t_dataflow_downstream_invalidation() -> str:
        df=DataFlowGraph()
        df.note_producer("execute_python",1); df.link_consumer("write_file")
        df.mark_done("execute_python")
        df.note_producer("write_file",2); df.link_consumer("read_file")
        blocked=df.invalidate_downstream("execute_python")
        assert set(blocked)=={"write_file","read_file"}, f"транзитивная блокировка неполна: {blocked}"
        try:
            df.check_executable("write_file"); denied=False
        except PolicyViolation: denied=True
        assert denied, "blocked-нода обязана быть не исполнимой"
        try:
            df.check_executable("read_file"); denied2=False
        except PolicyViolation: denied2=True
        assert denied2, "транзитивно заблокированная нода обязана быть не исполнимой"
        return "downstream invalidation: провал producer блокирует всех транзитивных потребителей"

    def t_side_effect_idempotency_across_resume() -> str:
        with tempfile.TemporaryDirectory(prefix="poly_t50_") as td:
            cfg,ws=_fresh_cfg(td)
            audit=AuditChain(Path(td)/"a.jsonl")
            # прогон 1: plan+act(write f.txt), затем имитация краха процесса ПОСЛЕ
            # in-loop checkpoint и ДО терминального _finalize (resume-сценарий)
            agent1=Agent(cfg, MockBrain([
                {"thought":"План.","status":"plan","success_criteria":["f.txt записан"],
                 "plan":["записать f.txt"]},
                {"thought":"Пишу.","status":"act",
                 "actions":[{"name":"write_file","args":{"path":"f.txt","content":"DATA48"}}]},
            ]), Governor(cfg,audit), audit)
            def crash_finalize(*a, **kw):
                raise KeyboardInterrupt("process died right after checkpoint")
            agent1._finalize=crash_finalize
            try:
                agent1.solve("resume идемпотентность T50")
            except KeyboardInterrupt:
                pass
            # прогон 2: НОВЫЙ Governor (пустой дедуп) + resume + тот же write_file
            agent2=Agent(cfg, MockBrain([
                {"thought":"Повторяю запись дословно.","status":"act",
                 "actions":[{"name":"write_file","args":{"path":"f.txt","content":"DATA48"}}]},
                {"thought":"Финал.","status":"final","outcome":"failed",
                 "final_answer":"T50: дубликат отклонён","lesson":"дедуп пережил resume"},
            ]), Governor(cfg,audit), audit)
            cap_state={}
            real_fin=agent2._finalize
            def capture_finalize(task_id,state,outcome,answer,started,lesson=""):
                cap_state.update(state)
                return real_fin(task_id,state,outcome,answer,started,lesson=lesson)
            agent2._finalize=capture_finalize
            res2=agent2.solve("resume идемпотентность T50")
            dup=[r for r in cap_state.get("ledger",[])
                 if "дубликат побочного вызова" in r.get("obs_brief","")]
            assert dup, "дубликат write_file после resume не отклонён дедупом — идемпотентность потеряна"
            return "идемпотентность переживает resume: дубликат write_file отклонён после краха+resume"

    def t_running_status_demoted_on_resume() -> str:
        with tempfile.TemporaryDirectory(prefix="poly_t51_") as td:
            cfg,_=_fresh_cfg(td); gov=Governor(cfg, AuditChain(Path(td)/"a.jsonl"), CatalogBridge(""))
            g=CapabilityGraph(gov.registry)
            spec=FormalGoalCompiler().compile_spec("исследуй тему через интернет",gov.registry,CapabilityPlanner(g))
            dag=ActionDAG(spec,g)
            dag.start("web_search")                       # крах ровно здесь: статус running
            snap=dag.snapshot()
            assert snap["web_search"]["status"]=="running"
            dag2=ActionDAG(spec,g); dag2.restore_snapshot(snap)
            assert dag2.nodes["web_search"].status=="pending", "running обязан демотироваться в pending"
            assert dag2.ready("web_search"), "демотированная нода обязана быть перевыполнимой"
            # завершённые статусы переживают restore без демоции
            dag_a=ActionDAG(spec,g)
            dag_a.start("web_search"); dag_a.complete("web_search",Observation(True,"net","ok"))
            dag3=ActionDAG(spec,g); dag3.restore_snapshot(dag_a.snapshot())
            assert dag3.nodes["web_search"].status=="completed", "completed не должен демотироваться"
            return "resume: running→pending (незавершённое не считается завершённым); completed сохранён"

    def t_dataflow_orphan_visibility() -> str:
        with tempfile.TemporaryDirectory(prefix="poly_t52_") as td:
            cfg,ws=_fresh_cfg(td)
            audit=AuditChain(Path(td)/"a.jsonl")
            agent=Agent(cfg, MockBrain([
                {"thought":"План.","status":"plan","success_criteria":["orphan.txt содержит данные"],
                 "plan":["осмотреться","записать файл"]},
                {"thought":"Осматриваюсь (не приближает критерий).","status":"act",
                 "actions":[{"name":"list_dir","args":{}}]},
                {"thought":"Пишу артефакт.","status":"act",
                 "actions":[{"name":"write_file","args":{"path":"orphan.txt","content":"данные"}}]},
                {"thought":"Артефакт записан.","status":"final","outcome":"verified",
                 "final_answer":"файл записан","lesson":"orphan виден"},
            ]), Governor(cfg,audit), audit)
            res=agent.solve("создай orphan.txt со словом данные")
            assert res["outcome"]=="verified", res
            df=agent.dataflow.snapshot()
            assert "list_dir" in df["orphans"], f"orphan не зафиксирован: {df}"
            assert "write_file" not in df["orphans"], "compiled-действие ложно помечено orphan"
            assert df["nodes"].get("write_file")=="done", "статус compiled-действия не done"
            return "orphan-видимость: list_dir вне DAG зафиксирован; compiled-действия чисты"

    def t_runtime_proof_gate_rejects_unproven() -> str:
        """T53: дефект v2.1.0 в runtime — вердикт принимался ДО proof-объекта.
        Сценарий: критерий «itog.txt содержит секрет-42» свидетелен по фактам
        (имя файла в квитанции записи), но содержимое артефакта («заглушка»)
        критерий НЕ подтверждает. ARTIFACT-контракт ловит это — старые гейты нет."""
        with tempfile.TemporaryDirectory(prefix="poly_t53_") as td:
            cfg,_=_fresh_cfg(td)
            audit=AuditChain(Path(td)/"a.jsonl")
            agent=Agent(cfg, MockBrain([
                {"thought":"План: записать файл и отчитаться.","status":"plan",
                 "success_criteria":["itog.txt содержит 'секрет-42'"],
                 "plan":["записать файл","финал"]},
                {"thought":"Пишу заглушку вместо ожидаемого содержимого.","status":"act",
                 "actions":[{"name":"write_file","args":{"path":"itog.txt","content":"заглушка"}}]},
                {"thought":"Имя файла в фактах — объявляю успех.","status":"final",
                 "outcome":"verified","final_answer":"файл записан"},
                {"thought":"Честный финал.","status":"final","outcome":"failed",
                 "final_answer":"T53: артефакт не подтверждает критерий","lesson":"artifact contract"},
            ]), Governor(cfg,audit), audit)
            cap_state={}
            real_fin=agent._finalize
            def capture_finalize(task_id,state,outcome,answer,started,lesson=""):
                cap_state.update(state)
                return real_fin(task_id,state,outcome,answer,started,lesson=lesson)
            agent._finalize=capture_finalize
            res=agent.solve("запиши отчёт в файл t53")
            gate_rows=[r for r in cap_state.get("ledger",[])
                       if r.get("action")=="(verify-fail)" and "Proof-гейтом" in r.get("obs_brief","")]
            assert gate_rows, "proof-гейт не отклонил VERIFIED: артефакт не подтверждает критерий"
            assert res["outcome"]=="failed", f"VERIFIED без доказательства не должен проходить: {res['outcome']}"
            assert res.get("proof_level")!="VERIFIED", "proof_level не должен быть VERIFIED"
            return "runtime proof gate: имитация успеха через квитанцию отклонена ARTIFACT-контрактом"

    def t_claim_compiler_contracts() -> str:
        """T54: Claim → ClaimType → EvidenceContract → RequiredEvidence → Rule → Proof."""
        with tempfile.TemporaryDirectory(prefix="poly_t54_") as td:
            pc=ProofCompiler()
            # ACTION: чужой SUCCESS не доказывает требуемое действие (ProviderSuccess ⊬ Claim)
            st={"required_capabilities":["write_file"],"criteria":[],"ledger":[
                {"step":1,"action":"web_search","ok":True,"kind":"net","obs_brief":"results"}],
                "facts":[],"_artifact_paths":[],"action_dag":{}}
            p=pc.derive("t54a",st)
            assert p.proof_level!="VERIFIED" and p.unknown_set, "чужой SUCCESS не должен давать VERIFIED"
            assert Agent._proof_allows_verified(p,st) is False
            # FACT: токен-свидетель в фактах успешного источника
            st2={"required_capabilities":[],"criteria":["исследование подтверждает квантовую запутанность"],
                 "ledger":[{"step":1,"action":"web_search","ok":True,"kind":"net","obs_brief":"квантовую запутанность наблюдали"}],
                 "facts":["#1 квантовую запутанность наблюдали"],"_artifact_paths":[],"action_dag":{}}
            p2=pc.derive("t54b",st2)
            claims2={c["claim_id"]:c for c in p2.claims}
            assert claims2["claim:crit:0"]["claim_type"]=="fact" and claims2["claim:crit:0"]["proven"], claims2
            # ARTIFACT: содержимое артефакта — свидетель
            art=Path(td)/"a.txt"; art.write_text("итоговый артефакт готов",encoding="utf-8")
            st3={"required_capabilities":[],"criteria":["a.txt содержит 'итоговый артефакт'"],
                 "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"файл создан"}],
                 "facts":["#1 файл создан"],"_artifact_paths":[str(art)],"action_dag":{}}
            p3=pc.derive("t54c",st3)
            c3={c["claim_id"]:c for c in p3.claims}["claim:crit:0"]
            assert c3["claim_type"]=="artifact" and c3["proven"], c3
            # пустая запись — НЕ свидетель (запрет имитации)
            art2=Path(td)/"b.txt"; art2.write_text("",encoding="utf-8")
            st4=dict(st3); st4["_artifact_paths"]=[str(art2)]
            st4["criteria"]=["b.txt содержит 'итоговый артефакт'"]
            p4=pc.derive("t54d",st4)
            c4={c["claim_id"]:c for c in p4.claims}["claim:crit:0"]
            assert not c4["proven"], "пустой артефакт не может быть свидетелем"
            # полный вывод: ACTION+ARTIFACT доказаны + evidence непуст → VERIFIED
            st5={"required_capabilities":["write_file"],"criteria":["a.txt содержит 'итоговый артефакт'"],
                 "ledger":[{"step":1,"action":"write_file","ok":True,"kind":"write","obs_brief":"файл создан: a.txt"}],
                 "facts":["#1 файл создан: a.txt"],"_artifact_paths":[str(art)],"action_dag":{}}
            p5=pc.derive("t54e",st5)
            assert p5.proof_level=="VERIFIED" and Agent._proof_allows_verified(p5,st5), \\
                f"полное доказательство обязано давать VERIFIED: {p5.proof_level}/{p5.unknown_set}"
            return "claim-компилятор: чужой SUCCESS не доказывает; пустой артефакт не свидетель; полный вывод даёт VERIFIED"

'''
