# -*- coding: utf-8 -*-
"""Блоки нового кода для сборки polymath_agent v2.2.0 (слияние веток v2.1.0)."""

HEADER_TITLE_OLD = 'polymath_agent.py — рабочее ядро целостного агента v1.5.0 «Арсенал+Исследование+Доказательство+Provenance+Recovery+Resume» (восстановлено из базы v2 после сброса среды 28.08.2026; v1.2.2–v1.2.4 — закалка живыми цепями).'

HEADER_TITLE_NEW = '''polymath_agent.py — рабочее ядро целостного агента v2.2.0 «Proof Gate + Claim Compiler» (слияние двух веток v2.1.0: ProofObject-ветка + DNS-pinning/DataFlow-ветка).
Единый файл. Только стандартная библиотека Python 3.9+. Внешних зависимостей НЕТ.

=== v2.2.0: СЛИЯНИЕ ДВУХ ВЕТОК v2.1.0 + ТРИ ДОКАЗАННЫХ ДЕФЕКТА ЗАКРЫТЫ ===
  Ветка А (ProofObject/ProofCompiler — Claim→Evidence→Rule) слита с веткой Б
  (DNS-Pinning/DependencyKnowledge/DataFlowGraph/Resume-hardening — Task Compiler 2.0).
  ДЕФЕКТ 1 «Мёртвый proof-гейт» (ветка А): _proof_allows_verified вызывался ТОЛЬКО
    в тестах T46/T47; реальный вердикт принимался ДО proof-объекта, а _finalize
    штамповал proof_level="VERIFIED" пост-фактум. ProofObject был квитанцией, не гейтом.
    ИСПРАВЛЕНИЕ: ProofCompiler вкомпилирован в runtime-путь вердикта: перед принятием
    VERIFIED доказательство СНАЧАЛА компилируется из claims (derive), затем
    _proof_allows_verified механически решает. Пустой evidence_set и/или недоказанные
    claims отклоняют VERIFIED (verify-fail, честный retry) — ProviderSuccess ⊬ Claim.
  ДЕФЕКТ 2 «Restore running → вечный deadlock» (ветка А): resume восстанавливал
    статус "running" слепо; start() требует pending, complete() требует running —
    крах во время действия замораживал capability навсегда. ИСПРАВЛЕНИЕ:
    ActionDAG.restore_snapshot демотирует running→pending (незавершённое через
    границу процесса не является завершённым).
  ДЕФЕКТ 3 «http_get мимо DNS-pinning» (ветка А): _t_http_get строил собственный
    opener поверх обычного резолва — guard резолвил DNS до соединения, сокет —
    повторно (TOCTOU/rebinding-дыра, OWASP SSRF Prevention Cheat Sheet).
    ИСПРАВЛЕНИЕ: все сетевые инструменты идут через pinned opener — dial только
    по валидированному IP; SNI/сертификат проверяются по оригинальному хосту.
  НОВЫЙ СЛОЙ — CLAIM → CLAIM TYPE → EVIDENCE CONTRACT → REQUIRED EVIDENCE →
    EVIDENCE → DETERMINISTIC RULE → PROOF → VERIFIED:
    ClaimType (ACTION/FACT/ARTIFACT), Claim, ProofCompiler.compile_claims/derive;
    per-claim контракты: ACTION→ok-строка нужного действия (чужой SUCCESS не
    доказывает); FACT→токен-свидетель в фактах успешных наблюдений-источников;
    ARTIFACT→существующий НЕПУСТОЙ артефакт с токеном критерия в содержимом
    (пустая запись свидетелем не признаётся).
  Регрессия: T44 dependency-knowledge, T45 dns-pinning, T46 proof object,
    T47 provider-success≠proof, T48 dataflow, T49 invalidation, T50 idempotency,
    T51 running-demotion, T52 orphans, T53 runtime proof-gate, T54 claim-compiler;
    T01–T43 сохранены (48 тестов суммарно).'''

NEW_HTTP_REQUEST_FN = '''def _http_request_no_redirect(url: str, cfg: "Config", method: str = "GET", data: Optional[bytes] = None):
    _ssrf_guard(url)
    req = urllib.request.Request(url, data=data, method=method, headers={
        "User-Agent": "polymath-agent/2.2 (+local research tool)",
        "Accept": "text/html, text/plain, application/json, application/xml;q=0.9,*/*;q=0.5"})
    return _pinned_opener().open(req, timeout=cfg.net_timeout_s)'''

NEW_SSRF_BLOCK = '''def _validate_resolved_addr(sa) -> None:
    """Валидация одного разрешённого адреса: приватные/резервные/loopback сети запрещены."""
    addr = ipaddress.ip_address(sa[0])
    if (addr.is_private or addr.is_loopback or addr.is_link_local
            or addr.is_reserved or addr.is_multicast or addr.is_unspecified):
        raise PolicyViolation(f"SSRF-фильтр: адрес {addr} относится к приватным сетям")


def _resolve_host(host: str) -> List[Tuple[str, int]]:
    """Единственная точка DNS-резолва сетевого контура. Возвращает список
    (ip, port_stub) и ВАЛИДИРУЕТ каждый адрес ДО возврата."""
    try:
        infos = socket.getaddrinfo(host, None)
    except OSError as e:
        raise PolicyViolation(f"SSRF-фильтр: DNS-резолв не удался ({e}) — блокирую")
    out = []
    for info in infos:
        sa = info[4][0]
        _validate_resolved_addr((sa, 0))
        if sa not in [x[0] for x in out]:
            out.append((sa, 0))
    if not out:
        raise PolicyViolation("SSRF-фильтр: пустой результат DNS-резолва")
    return out


def _ssrf_guard(url: str) -> None:
    """Fast-fail гейт: схема, хост-чёрный список, внутренние зоны, DNS-валидация.
    Авторитетная проверка выполняется повторно в точке соединения (pinning)."""
    m = re.match(r"^https?://[^/]+", url or "")
    if not m:
        raise PolicyViolation("url обязан быть абсолютным http(s)-адресом")
    host = re.match(r"^https?://([^/:?#]+)", url).group(1).strip("[]").lower()
    if host in _BAD_HOSTNAMES:
        raise PolicyViolation(f"SSRF-фильтр: хост '{host}' запрещён")
    if host.endswith(".local") or host.endswith(".internal"):
        raise PolicyViolation(f"SSRF-фильтр: домен внутренней зоны '{host}' запрещён")
    _resolve_host(host)


class _PinnedHTTPConnection(http.client.HTTPConnection):
    """HTTP-соединение по валидированному IP. Резолв выполняется РОВНО ОДИН раз
    здесь; socket.create_connection получает уже проверенный IP, а не имя хоста —
    второй резолв, которым пользуется rebinding-атака, механически исключён."""
    def connect(self):
        pinned = _resolve_host(self.host)[0][0]      # авторитетный резолв+валидация
        self._pinned_ip = pinned
        self.sock = socket.create_connection((pinned, self.port), self.timeout,
                                             source_address=self.source_address)


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    """HTTPS-соединение по валидированному IP с сохранением SNI/сертификата:
    socket дial'ит проверенный IP, TLS-handshake верифицирует ОРИГИНАЛЬНЫЙ хост."""
    def connect(self):
        pinned = _resolve_host(self.host)[0][0]      # авторитетный резолв+валидация
        self._pinned_ip = pinned
        sock = socket.create_connection((pinned, self.port), self.timeout,
                                        source_address=self.source_address)
        if self._tunnel_host:
            server_hostname = self._tunnel_host
        else:
            server_hostname = self.host
        self.sock = self._context.wrap_socket(sock, server_hostname=server_hostname)


class _PinnedHTTPHandler(urllib.request.HTTPHandler):
    def http_open(self, req):
        return self.do_open(_PinnedHTTPConnection, req)


class _PinnedHTTPSHandler(urllib.request.HTTPSHandler):
    def https_open(self, req):
        return self.do_open(_PinnedHTTPSConnection, req, context=self._context)


def _pinned_opener() -> urllib.request.OpenerDirector:
    """Opener: без редиректов + pinning соединений."""
    return urllib.request.build_opener(_NoRedirect, _PinnedHTTPHandler,
                                       _PinnedHTTPSHandler)'''

NEW_SUBSTITUTE_VARS = '''def _substitute_vars(args: Any, state: Dict[str, Any]) -> Tuple[Any, bool, bool]:
    """Механическая подстановка $last_output — вывод последнего успешного действия —
    в args действия. Рекурсия по dict/list; замена ТОЛЬКО точного совпадения строки
    (строка, равная переменной целиком), чтобы не калечить данные модели.
    Возвращает (args, missing, substituted):
      missing=True — переменная упомянута, но ещё не существует (честное отклонение);
      substituted=True — подстановка фактически произошла (для DataFlow-ребра
      producer→consumer: v2.2.0 компилирует из этого реальную зависимость данных)."""
    missing = [False]
    substituted = [False]

    def walk(x):
        if isinstance(x, str):
            if x.strip() == LAST_OUTPUT_VAR:
                lo = state.get("_last_output")
                if lo is None:
                    missing[0] = True
                    return x
                substituted[0] = True
                return lo
            return x
        if isinstance(x, dict):
            return {k: walk(v) for k, v in x.items()}
        if isinstance(x, list):
            return [walk(v) for v in x]
        return x

    return walk(args), missing[0], substituted[0]'''

GOVERNOR_SE_METHODS = '''
    # --- v2.2.0: идемпотентность побочных вызовов переживает checkpoint ---
    def seen_side_effect_snapshot(self) -> Dict[str, int]:
        return dict(self._seen_side_effect)

    def restore_seen_side_effect(self, snap: Dict[str, int]) -> None:
        for k, v in (snap or {}).items():
            try: self._seen_side_effect.setdefault(str(k), int(v))
            except Exception: continue
'''

CAPABILITY_GRAPH_NEW = '''class CapabilityGraph:
    """Граф возможностей и зависимостей.
    v2.2.0 (из ветки Б): DependencyKnowledge — механическая база ОБЯЗАТЕЛЬНЫХ
    предпосылок. Дефект доказан аудит-цепью: без этой базы продакшн-граф строился
    пустым (deps=[]), dependency guard был мёртв в бою, а фактический необходимый
    источник (web_search для research_web) не попадал даже в план.
    Знание зависит только от реестра инструментов и детерминировано."""
    DEPENDENCY_KNOWLEDGE = {
        "research_web": ["web_search"],   # исследование: discovery предшествует fetch
    }
    def __init__(self, registry, seed_knowledge: bool = True):
        self.nodes={n:{"name":n,"risk":sp.risk,"description":sp.doc,"deps":[]} for n,sp in registry.items()}
        if seed_knowledge:
            self.seed_dependency_knowledge()
    def seed_dependency_knowledge(self) -> None:
        """Засеять семантические предпосылки из DependencyKnowledge (детерминированно)."""
        for name, deps in self.DEPENDENCY_KNOWLEDGE.items():
            for dep in deps:
                self.add_dependency(name, dep)
    def add_dependency(self, name, dep):
        if name in self.nodes and dep in self.nodes and dep != name and dep not in self.nodes[name]["deps"]:
            self.nodes[name]["deps"].append(dep)
    def closure(self, requested):
        out=[]; seen=set()
        def visit(n):
            if n in seen or n not in self.nodes: return
            seen.add(n)
            for d in self.nodes[n]["deps"]: visit(d)
            out.append(n)
        for n in requested: visit(n)
        return out'''

DATAFLOW_CLASS = '''class DataFlowGraph:
    """Семантический граф потока данных КОНКРЕТНОЙ задачи поверх ActionDAG (ветка Б).
    Capability-dependency ≠ actual action-dependency: «результат действия A → вход
    действия B» выражается здесь. DataFlowGraph компилирует реальные producer→consumer
    рёбра:
      * источник ребра — действие, чей вывод стал _last_output (producer);
      * приёмник — действие, чьи args содержали $last_output (consumer);
      * каждое ребро пишется в EvidenceGraph как «action:X feeds action:Y» —
        поток данных становится потоком доказательств.
    Механика исполнения:
      * blocked-нода (упал её producer) не исполняется: PolicyViolation ДО gov.run;
      * invalidate_downstream транзитивно блокирует потребителей при провале
        producer'а (запрет передачи неподтверждённого результата);
      * _assert_acyclic закрывает циклы (инвариант проверяется при каждом restore);
      * executes вне compiled DAG фиксируются как orphan — честная видимость.
    Статусы нод: pending → running → done | blocked.
    Сериализация: snapshot()/restore_snapshot() — переживает checkpoint."""

    def __init__(self):
        self.nodes: Dict[str, str] = {}          # cap -> pending|running|done|blocked
        self.edges: List[Dict[str, Any]] = []    # {src, dst, via, producer_step}
        self.orphans: List[str] = []             # исполненные действия вне compiled DAG
        self._last_producer: Optional[str] = None
        self._last_producer_step: int = 0

    # --- компиляция рёбер ---
    def note_producer(self, cap: Optional[str], producer_step: int) -> None:
        """Зафиксировать источник текущего _last_output (после успешного действия)."""
        self._last_producer = cap if cap else "external"
        self._last_producer_step = producer_step

    def link_consumer(self, cap: str) -> Optional[Dict[str, Any]]:
        """Добавить ребро producer→consumer для действия, потребовавшего $last_output.
        Ребро цикла механически невозможно ($last_output существует только у прошлых
        действий), но self-ребро отвергается явно."""
        if self._last_producer is None:
            return None
        src = self._last_producer
        if src == cap:
            raise PolicyViolation(f"dataflow: действие '{cap}' не может потреблять собственный вывод")
        edge = {"src": src, "dst": cap, "via": "$last_output",
                "producer_step": self._last_producer_step}
        if not any(e["src"] == src and e["dst"] == cap for e in self.edges):
            self.edges.append(edge)
            self._assert_acyclic()
        return edge

    def note_orphan(self, cap: str) -> None:
        """Действие вне compiled ActionDAG: не приближает ни один критерий — фиксируем."""
        if cap not in self.nodes and cap not in self.orphans:
            self.orphans.append(cap)

    # --- статусы и механика запрета ---
    def ensure_node(self, cap: str) -> None:
        self.nodes.setdefault(cap, "pending")

    def mark_running(self, cap: str) -> None:
        self.ensure_node(cap); self.nodes[cap] = "running"

    def mark_done(self, cap: str) -> None:
        self.ensure_node(cap); self.nodes[cap] = "done"

    def invalidate_downstream(self, cap: str) -> List[str]:
        """Провал producer'а: транзитивно блокирует всех потребителей и их
        потребителей. Возвращает список заблокированных нод."""
        self.ensure_node(cap); self.nodes[cap] = "blocked"
        blocked, frontier = [], [cap]
        while frontier:
            cur = frontier.pop()
            for e in self.edges:
                if e["src"] == cur:
                    dst = e["dst"]
                    if self.nodes.get(dst) not in {"blocked"}:
                        self.nodes[dst] = "blocked"
                        blocked.append(dst)
                        frontier.append(dst)
        return blocked

    def check_executable(self, cap: str) -> None:
        """Механический запрет исполнения заблокированной ноды (PolicyViolation
        ДО gov.run): передача недоступного/неподтверждённого результата запрещена."""
        status = self.nodes.get(cap)
        if status == "blocked":
            raise PolicyViolation(
                f"dataflow guard: действие '{cap}' заблокировано — провалился его "
                f"producer; входные данные недостоверны, исполнение запрещено")

    def _assert_acyclic(self) -> None:
        graph: Dict[str, List[str]] = {}
        for e in self.edges:
            graph.setdefault(e["src"], []).append(e["dst"])
        state: Dict[str, int] = {}
        def dfs(n: str) -> None:
            if state.get(n) == 1:
                raise PolicyViolation(f"dataflow: обнаружен цикл через '{n}'")
            if state.get(n) == 2:
                return
            state[n] = 1
            for m in graph.get(n, []):
                dfs(m)
            state[n] = 2
        for n in list(graph):
            dfs(n)

    # --- сериализация ---
    def snapshot(self) -> Dict[str, Any]:
        return {"nodes": dict(self.nodes), "edges": [dict(e) for e in self.edges],
                "orphans": list(self.orphans)}

    def restore_snapshot(self, snap: Dict[str, Any]) -> None:
        snap = snap or {}
        self.nodes = dict(snap.get("nodes", {}))
        self.edges = [dict(e) for e in snap.get("edges", [])]
        self.orphans = list(snap.get("orphans", []))
        self._assert_acyclic()


'''

RESTORE_SNAPSHOT_METHOD = '''    def restore_snapshot(self, snap: Dict[str, Any]) -> None:
        """v2.2.0: восстановление с МЕХАНИЧЕСКОЙ демоцией невозможных статусов.
        «running» не может пересечь границу процесса: между checkpoint-ом и крахом
        ни один action не был завершён, значит с точки зрения верификации он
        НЕ выполнен и обязан быть перевыполнен — демоция running→pending.
        (Дефект v2.1.0: слепое восстановление running замораживало ноду навсегда —
        start() требует pending, complete() требует running.)
        Статусы completed/failed сохраняются."""
        for cap, st in (snap or {}).items():
            if cap not in self.nodes: continue
            status = st.get("status", "pending")
            if status == "running":
                status = "pending"          # демоция: незавершённое — не завершённое
            if status not in {"pending", "completed", "failed"}:
                status = "pending"
            self.nodes[cap].status = status
'''

CLAIM_BLOCKS = '''class ClaimType:
    """v2.2.0: типы утверждений — каждому типу соответствует СВОЙ контракт доказательства.
      ACTION-claim   → required_action: в ledger есть ok-строка ИМЕННО этого действия;
      FACT-claim     → source_kind: токен-свидетель в фактах успешных наблюдений-источников;
      ARTIFACT-claim → artifact_path: существующий НЕПУСТОЙ артефакт с токеном критерия."""
    ACTION = "action"
    FACT = "fact"
    ARTIFACT = "artifact"


@dataclass
class Claim:
    """Атомарное утверждение с контрактом требуемого доказательства."""
    claim_id: str
    text: str
    claim_type: str                 # action|fact|artifact
    required_action: str = ""       # контракт ACTION
    source_kind: str = ""           # контракт FACT: ожидаемые роды источников
    artifact_path: str = ""         # контракт ARTIFACT: путь артефакта
    tokens: List[str] = field(default_factory=list)
    proven: bool = False
    evidence_refs: List[str] = field(default_factory=list)

    def as_dict(self) -> Dict[str, Any]:
        return dict(self.__dict__)


class ProofCompiler:
    """v2.2.0: компилятор доказательств —
    CLAIM → CLAIM TYPE → EVIDENCE CONTRACT → REQUIRED EVIDENCE →
         → EVIDENCE → DETERMINISTIC RULE → PROOF → VERIFIED.

    Главная аксиома (закреплена механически): ProviderSuccess ⊬ Claim.
    Успешное Observation само по себе ничего не доказывает: доказательством
    признаётся только свидетельство, удовлетворяющее контракту ТИПА claim'а.

    Правила вывода (детерминированные, без участия модели):
      ACTION-claim:   в ledger есть ok-строка action==required_action
                      (свидетель требуемой capability, не «чужой» SUCCESS);
      FACT-claim:     критерий имеет токен-свидетель в кумулятивной базе фактов
                      успешных наблюдений (факт добыт ИСТОЧНИКОМ, а не квитанцией);
      ARTIFACT-claim: артефакт существует, НЕПУСТ, и токен критерия живёт в его
                      содержимом (пустая запись свидетелем не признаётся).

    VERIFIED выдаётся ТОЛЬКО если все claims доказаны по своим контрактам И
    evidence_set непуст. Иначе — OBSERVED/UNKNOWN с честным unknown_set."""

    def compile_claims(self, state: Dict[str, Any]) -> List[Claim]:
        claims: List[Claim] = []
        # ACTION-claims: компилируются из required_capabilities GoalSpec
        for cap in state.get("required_capabilities", []):
            claims.append(Claim(claim_id=f"claim:cap:{cap}",
                                text=f"capability {cap} выполнена успешно",
                                claim_type=ClaimType.ACTION, required_action=cap))
        # FACT/ARTIFACT-claims: компилируются из success-критериев
        art_paths = list(state.get("_artifact_paths", []))
        for i, crit in enumerate(state.get("criteria", [])):
            lits = [l.strip() for l in re.findall(r"[\\'\\"]([^\\'\\"]+)[\\'\\"]", crit)]
            literal = lits[0] if lits else None
            named = next((p for p in art_paths
                          if Path(p).name in crit or p in crit), None)
            if named:
                # v2.2.1-фикс: литерал обязателен и в ARTIFACT-контракте —
                # цитируемое содержимое есть само обещание критерия
                # (регрессия T10 поймала пропуск: 'hi' не попадал в tokens).
                toks = self._tokens(crit)
                if literal and len(literal) >= 2:
                    toks = toks + [literal.lower()]
                claims.append(Claim(claim_id=f"claim:crit:{i}", text=crit,
                                    claim_type=ClaimType.ARTIFACT,
                                    artifact_path=named, tokens=toks))
            else:
                toks = self._tokens(crit)
                if literal and len(literal) >= 2:
                    toks = toks + [literal.lower()]
                claims.append(Claim(claim_id=f"claim:crit:{i}", text=crit,
                                    claim_type=ClaimType.FACT,
                                    source_kind="net,research,exec,read,list,memory",
                                    tokens=toks))
        return claims

    @staticmethod
    def _tokens(crit: str) -> List[str]:
        toks = [t for t in re.findall(r"[\\w\\./\\-]+", crit.lower()) if len(t) >= 4]
        return toks or [crit.lower().strip()]

    def derive(self, task_id: str, state: Dict[str, Any]) -> ProofObject:
        claims = self.compile_claims(state)
        ledger = state.get("ledger", [])
        ok_rows = [r for r in ledger
                   if r.get("ok") and r.get("action") not in {"(план)", "(verify-fail)"}]
        successful_actions = {r.get("action") for r in ok_rows}
        facts_blob = " ".join(f for f in state.get("facts", [])
                              if "(0 символов)" not in f).lower()
        evidence_set = [{"ref": f"step:{r.get('step')}:{r.get('action')}",
                         "kind": r.get("kind"), "ok": True,
                         "brief": r.get("obs_brief", "")} for r in ok_rows]
        unknowns: List[str] = []
        for c in claims:
            if c.claim_type == ClaimType.ACTION:
                c.proven = c.required_action in successful_actions
                if c.proven:
                    c.evidence_refs = [f"step:{r.get('step')}:{r.get('action')}"
                                       for r in ok_rows if r.get("action") == c.required_action]
            elif c.claim_type == ClaimType.FACT:
                c.proven = bool(c.tokens) and any(t in facts_blob for t in c.tokens)
            elif c.claim_type == ClaimType.ARTIFACT:
                body = ""
                try:
                    body = Path(c.artifact_path).read_text(
                        encoding="utf-8", errors="replace").lower()
                except Exception:
                    body = ""
                c.proven = bool(body.strip()) and any(t in body for t in c.tokens)
            if not c.proven:
                unknowns.append(f"{c.claim_type}:{c.text[:120]}")
        if claims and all(c.proven for c in claims) and evidence_set:
            level = "VERIFIED"
        elif evidence_set:
            level = "OBSERVED"
        else:
            level = "UNKNOWN"
        return ProofObject(
            status="verified" if level == "VERIFIED" else "pending",
            task_id=task_id, intent_ref=f"goal:{task_id}",
            authorization_ref=f"policy:{task_id}",
            execution_refs=[f"step:{r.get('step')}:{r.get('action')}"
                            for r in ledger if r.get("action") not in {"(план)"}],
            observation_refs=[f"step:{r.get('step')}:{r.get('action')}" for r in ok_rows],
            verification_refs=[f"verification:{task_id}"],
            evidence_set=evidence_set, dependency_set=state.get("action_dag", {}),
            proof_level=level, unknown_set=unknowns,
            claims=[c.as_dict() for c in claims])


'''

PROOF_OBJECT_FIELD_OLD = '    unknown_set: List[str] = field(default_factory=list)\n    generated_at: float = field(default_factory=time.time)'
PROOF_OBJECT_FIELD_NEW = '    unknown_set: List[str] = field(default_factory=list)\n    claims: List[Dict[str, Any]] = field(default_factory=list)   # v2.2.0: per-claim статусы\n    generated_at: float = field(default_factory=time.time)'
