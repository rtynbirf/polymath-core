#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Извлечение чистого polymath_agent.py из вставки с двойной нумерацией строк."""
import re
from pathlib import Path

SRC = Path("/home/z/my-project/upload/Pasted Content_1787918895204.txt")
DST = Path("/home/z/my-project/download/polymath_agent.py")
DST.parent.mkdir(parents=True, exist_ok=True)

raw = SRC.read_text(encoding="utf-8", errors="replace")
out_lines = []
dropped = 0
for ln in raw.splitlines():
    # снять собственную нумерацию вставки: "  123→текст"
    m = re.match(r"^\s*\d+→(.*)$", ln)
    body = m.group(1) if m else ln
    if dropped < 2 and ("ТЫ ПОЛИМАТ" in body or "ДЛЯ ЧЕГО" in body):
        dropped += 1
        continue
    out_lines.append(body)

text = "\n".join(out_lines).lstrip("\n")
DST.write_text(text, encoding="utf-8")
print(f"записано: {DST} ({len(text)} символов, {text.count(chr(10))+1} строк)")

# синтаксическая проверка
import py_compile
try:
    py_compile.compile(str(DST), doraise=True)
    print("синтаксис: OK")
except py_compile.PyCompileError as e:
    print("синтаксис: FAIL")
    print(e)
