#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Стадия 2 сборки v3.4.0: RevocationCascade v2 + commit-путь + KnowledgeAuditor +
runtime binding + wiring + реставрация тестов-хранителей + новые тесты."""
from pathlib import Path

src = Path("/home/z/my-project/scripts/_v340_stage1.py").read_text(encoding="utf-8")

def splice(old: str, new: str, name: str) -> None:
    global src
    n = src.count(old)
    assert n == 1, f"[{name}] якорь встречается {n} раз (ожидался 1)"
    src = src.replace(old, new)
    print(f"  [OK] {name}")

# ─── SP-11: FalsificationProbe + infer_from_ledger (живой захват противоречий) ──
splice(
"""class FalsificationProbe:
    \"\"\"Conservative pre-commit contradiction gate. Unknown is never converted to support.\"\"\"
    @staticmethod
    def probe(state: Dict[str,Any], proof: ProofObject) -> Dict[str,Any]:
        claims=set(proof.claim_ids); contested=set(); refuted=set(); reasons=[]
        for row in state.get("falsification",[]):
            if not isinstance(row,dict) or row.get("claim_id") not in claims: continue
            verdict=str(row.get("verdict","")).upper()
            if verdict==FalsificationVerdict.REFUTED:
                refuted.add(row["claim_id"]); reasons.append(row.get("reason","refuted"))
            elif verdict==FalsificationVerdict.CONTESTED:
                contested.add(row["claim_id"]); reasons.append(row.get("reason","contested"))
        if refuted: return {"status":"REFUTED","claims":sorted(refuted),"reasons":reasons}
        if contested: return {"status":"CONTESTED","claims":sorted(contested),"reasons":reasons}
        return {"status":"CLEAR","claims":[],"reasons":[]}
""",
"""class FalsificationProbe:
    \"\"\"Conservative pre-commit contradiction gate. Unknown is never converted to support.\"\"\"
    @staticmethod
    def infer_from_ledger(state: Dict[str,Any], proof: ProofObject) -> List[Dict[str,Any]]:
        \"\"\"v3.4.0 N-FALS: механический захват противоречий из журнала.

        Консервативное правило (только CONTESTED, никогда REFUTED): verify-fail,
        назвавший критерий claim'а ПОСЛЕ его последнего поддерживающего evidence,
        означает, что мир перестал соответствовать наблюдению → COMMIT запрещён
        до свежего evidence. Свежее evidence (шаг позже verify-fail) снимает
        CONTESTED — контур STALE/CONTESTED → RE-CHECK → NEW PROOF → CAS → COMMIT замкнут.
        \"\"\"
        rows=[r for r in state.get("ledger",[]) if isinstance(r,dict)]
        out=[]
        node_claims={n.get("claim_id") for n in proof.nodes if isinstance(n,dict) and n.get("kind")=="claim"}
        ev_step={}
        for n in proof.nodes:
            if not (isinstance(n,dict) and n.get("kind")=="claim" and n.get("claim_id")):
                continue
            cid=n["claim_id"]; steps=[]
            for did in n.get("inputs",[]):
                for dn in proof.nodes:
                    if isinstance(dn,dict) and dn.get("id")==did and dn.get("kind")=="derivation":
                        for eid in dn.get("inputs",[]):
                            parts=str(eid).split(":")
                            if len(parts)>=3 and parts[1]=="step":
                                try: steps.append(int(parts[2]))
                                except ValueError: pass
            if steps: ev_step[cid]=max(steps)
        for cid in sorted(proof.claim_ids):
            if cid not in node_claims or cid not in ev_step: continue
            try: idx=int(cid.split(":")[1])-1
            except (IndexError,ValueError): continue
            criteria=state.get("criteria",[])
            if not (0<=idx<len(criteria)): continue
            criterion=str(criteria[idx]); last=ev_step[cid]
            for r in rows:
                if r.get("kind")!="verify" or r.get("ok") is not False: continue
                try: rstep=int(r.get("step",0))
                except (TypeError,ValueError): continue
                if rstep>last and criterion in str(r.get("obs_brief","")):
                    out.append({"claim_id":cid,"verdict":"CONTESTED",
                                "reason":f"ledger verify-fail at step {rstep} after evidence at step {last}"})
                    break
        return out
    @staticmethod
    def probe(state: Dict[str,Any], proof: ProofObject) -> Dict[str,Any]:
        claims=set(proof.claim_ids); contested=set(); refuted=set(); reasons=[]
        # v3.4.0 N-FALS: явные вердикты + механически захваченные из журнала противоречия
        rows=list(state.get("falsification",[])) + FalsificationProbe.infer_from_ledger(state,proof)
        for row in rows:
            if not isinstance(row,dict) or row.get("claim_id") not in claims: continue
            verdict=str(row.get("verdict","")).upper()
            if verdict==FalsificationVerdict.REFUTED:
                refuted.add(row["claim_id"]); reasons.append(row.get("reason","refuted"))
            elif verdict==FalsificationVerdict.CONTESTED:
                contested.add(row["claim_id"]); reasons.append(row.get("reason","contested"))
        if refuted: return {"status":"REFUTED","claims":sorted(refuted),"reasons":reasons}
        if contested: return {"status":"CONTESTED","claims":sorted(contested),"reasons":reasons}
        return {"status":"CLEAR","claims":[],"reasons":[]}
""",
"SP-11 FalsificationProbe.infer_from_ledger")

# ─── SP-12: RevocationCascade v2 (dependency-aware) ─────────────────────────
splice(
"""    @classmethod
    def apply(cls, state: Dict[str, Any], proof: ProofObject) -> List[Dict[str, str]]:
        \"\"\"При mutation/replacement/removal одного bound artifact инвалидирует весь
        зависимый proof-chain. Консервативность намеренна: v3.3.x не хранит
        per-evidence artifact edges, поэтому безопасно ревокировать весь proof.
        \"\"\"
        mismatches=cls.detect_artifact_mismatches(state, proof)
        if not mismatches:
            return []
        state["revocation"]={
            "status":"REVOKED",
            "reason":"artifact_mutation",
            "artifacts":mismatches,
            "revoked_at":now_iso(),
            "evidence_ids":list(proof.evidence_ids),
            "claim_ids":list(proof.claim_ids),
            "proof_id":proof.id,
        }
        for row in state.get("derivations", []):
            if row.get("claim_id") in proof.claim_ids:
                row["status"]="revoked"
                row["revocation_reason"]="artifact_mutation"
        state["revoked_evidence_ids"]=list(proof.evidence_ids)
        state["revoked_claim_ids"]=list(proof.claim_ids)
        state["knowledge_status"]="REVOKED"
        return mismatches
""",
"""    @staticmethod
    def _affected_claims(proof: ProofObject, revoked_evidence: List[str]) -> List[str]:
        \"\"\"v3.4.0: claims, чьи деривации опираются на отозванное evidence.\"\"\"
        support={}
        for n in proof.nodes:
            if isinstance(n,dict) and n.get("kind")=="derivation" and n.get("claim_id"):
                support.setdefault(n["claim_id"],set()).update(n.get("inputs",[]))
        return sorted(cid for cid,eids in support.items() if eids & set(revoked_evidence))

    @staticmethod
    def detect_evidence_drift(state: Dict[str, Any], proof: ProofObject) -> List[Dict[str, str]]:
        \"\"\"v3.4.0: дрейф мира относительно состояния В МОМЕНТ наблюдения evidence.
        Закрывает revival-дыру: перезапись глобального пина при перекомпиляции
        не должна launder'ить старое evidence через новые хеши.\"\"\"
        drift=[]
        for eid,edges in (proof.artifact_edges or {}).items():
            if not isinstance(edges,dict): continue
            for path,pin in edges.items():
                try: cur=sha256_hex(Path(path).read_bytes())
                except Exception: cur="MISSING"
                if cur!=pin:
                    drift.append({"evidence":eid,"artifact":path,"expected":pin,"actual":cur})
        return drift

    @classmethod
    def apply_drift(cls, state: Dict[str, Any], proof: ProofObject, drift: List[Dict[str, str]]) -> None:
        \"\"\"v3.4.0: точная ревокация по evidence-дрейфу (до вынесения вердикта COMMIT).\"\"\"
        bad={d["artifact"] for d in drift}
        revoked=sorted(eid for eid,edges in (proof.artifact_edges or {}).items()
                       if isinstance(edges,dict) and any(p in bad for p in edges))
        affected=cls._affected_claims(proof,revoked)
        state["revocation"]={"status":"REVOKED","reason":"evidence_artifact_drift",
                             "artifacts":sorted(bad),"drift":drift,"revoked_at":now_iso(),
                             "evidence_ids":revoked,"claim_ids":affected,"proof_id":proof.id}
        for row in state.get("derivations", []):
            if row.get("claim_id") in affected:
                row["status"]="revoked"; row["revocation_reason"]="evidence_artifact_drift"
        state["revoked_evidence_ids"]=revoked
        state["revoked_claim_ids"]=affected
        state["knowledge_status"]="REVOKED"

    @classmethod
    def apply(cls, state: Dict[str, Any], proof: ProofObject) -> List[Dict[str, str]]:
        \"\"\"v3.4.0 dependency-aware revocation: мутация/удаление bound-артефакта
        инвалидирует ТОЛЬКО связанное знание (evidence с рёбрами к изменённому
        пути, их claims и деривации). Proof'ы без рёбер (legacy) ревокируются
        консервативно целиком — совместимость со старыми proof-объектами.\"\"\"
        mismatches=cls.detect_artifact_mismatches(state, proof)
        if not mismatches:
            return []
        bad={m["artifact"] for m in mismatches}
        revoked=sorted(eid for eid,edges in (proof.artifact_edges or {}).items()
                       if isinstance(edges,dict) and any(p in bad for p in edges))
        if revoked:
            affected=cls._affected_claims(proof,revoked)
        else:
            # legacy-proof без per-evidence рёбер: консервативный полный каскад
            revoked=sorted(proof.evidence_ids); affected=sorted(proof.claim_ids)
        state["revocation"]={
            "status":"REVOKED",
            "reason":"artifact_mutation",
            "artifacts":mismatches,
            "revoked_at":now_iso(),
            "evidence_ids":revoked,
            "claim_ids":affected,
            "proof_id":proof.id,
        }
        for row in state.get("derivations", []):
            if row.get("claim_id") in affected:
                row["status"]="revoked"
                row["revocation_reason"]="artifact_mutation"
        state["revoked_evidence_ids"]=revoked
        state["revoked_claim_ids"]=affected
        state["knowledge_status"]="REVOKED"
        return mismatches
""",
"SP-12 RevocationCascade v2")

# ─── SP-13a: commit — revival-hole gate перед каскадом ──────────────────────
splice(
"""        StateCAS.assert_unchanged(state,proof)
        mismatches=RevocationCascade.apply(state,proof)
        if mismatches:
            raise ProofCarryingCommitError("COMMIT: REVOKED — bound artifact mutation")
""",
"""        StateCAS.assert_unchanged(state,proof)
        # v3.4.0 revival-hole gate: evidence-пины (состояние мира В МОМЕНТ наблюдения)
        # сверяются с текущим миром ДО разрешения COMMIT. Перезапись глобального пина
        # при перекомпиляции не launder'ит старое evidence.
        drift=RevocationCascade.detect_evidence_drift(state,proof)
        if drift:
            RevocationCascade.apply_drift(state,proof,drift)
            raise ProofCarryingCommitError("COMMIT: REVOKED — evidence-bound artifact mutation: "+", ".join(sorted({d['artifact'] for d in drift})))
        mismatches=RevocationCascade.apply(state,proof)
        if mismatches:
            raise ProofCarryingCommitError("COMMIT: REVOKED — bound artifact mutation")
""",
"SP-13a commit drift gate")

# ─── SP-13b: commit — закрытие REVOKED-записи при успехе ────────────────────
splice(
"""        state["epistemic_reconciliation"]=reconciliation
        state["commit"]={"status":"committed","proof_id":proof.id,"committed_at":now_iso(),"world_verdict":reconciliation["world_verdict"]}
        anchor_path=state.get("_proof_anchor_path")
""",
"""        state["epistemic_reconciliation"]=reconciliation
        state["commit"]={"status":"committed","proof_id":proof.id,"committed_at":now_iso(),"world_verdict":reconciliation["world_verdict"]}
        # v3.4.0 N-RES: успешный COMMIT закрывает предыдущую REVOKED-запись
        # с сохранением истории — консистентность знания после re-proof.
        _rev=state.get("revocation")
        if isinstance(_rev,dict) and _rev.get("status")=="REVOKED":
            state.setdefault("revocation_history",[]).append({**_rev,"resolved_at":now_iso(),"resolved_by":proof.id})
            state["revocation"]={"status":"RESOLVED","resolved_at":now_iso(),
                                 "resolved_by":proof.id,"reason":_rev.get("reason")}
            state["knowledge_status"]="VALID"
        anchor_path=state.get("_proof_anchor_path")
""",
"SP-13b revocation resolution")

# ─── SP-14: Governor.validate восстанавливает artifact_edges ────────────────
splice(
"""        proof=ProofObject(raw["id"],raw["status"],list(raw["claim_ids"]),list(raw["evidence_ids"]),raw["rule"],list(raw["unknowns"]),raw.get("rule_version",""),list(raw.get("nodes",[])),list(raw.get("edges",[])),dict(raw.get("evidence_hashes",{})),raw.get("created_at",now_iso()),dict(raw.get("evidence_timestamps",{})),dict(raw.get("artifact_hashes",{})),raw.get("source_state_hash",""),int(raw.get("state_version",0)))
""",
"""        _edges_raw=raw.get("artifact_edges",{})
        _edges={k:dict(v) for k,v in _edges_raw.items() if isinstance(v,dict)} if isinstance(_edges_raw,dict) else {}
        proof=ProofObject(raw["id"],raw["status"],list(raw["claim_ids"]),list(raw["evidence_ids"]),raw["rule"],list(raw["unknowns"]),raw.get("rule_version",""),list(raw.get("nodes",[])),list(raw.get("edges",[])),dict(raw.get("evidence_hashes",{})),raw.get("created_at",now_iso()),dict(raw.get("evidence_timestamps",{})),dict(raw.get("artifact_hashes",{})),raw.get("source_state_hash",""),int(raw.get("state_version",0)),_edges)
""",
"SP-14 validate reconstructs artifact_edges")

# ─── SP-15: KnowledgeAuditor (post-commit drift) ────────────────────────────
splice(
"""class EvidenceGraph:
    \"\"\"Граф claim/observation/artifact/verification.\"\"\"
""",
"""class KnowledgeAuditor:
    \"\"\"v3.4.0 N-DRIFT: сверка ЗАКРЕПЛЁННОГО знания с миром вне commit-пути.
    COMMIT проверяет мир в момент коммита; мутация ПОСЛЕ коммита делает
    закреплённое знание STALE — это обнаруживается аудитом, а не только
    следующей попыткой коммита.\"\"\"
    @staticmethod
    def audit(state: Dict[str, Any]) -> Dict[str, Any]:
        commit_rec=state.get("commit") if isinstance(state.get("commit"),dict) else {}
        proof=state.get("proof") if isinstance(state.get("proof"),dict) else {}
        if commit_rec.get("status")!="committed" or not proof:
            return {"status":"NO_COMMITTED_KNOWLEDGE","drift":[]}
        drift=[]; seen=set()
        for eid,edges in (proof.get("artifact_edges") or {}).items():
            if not isinstance(edges,dict): continue
            for path,pin in edges.items():
                try: cur=sha256_hex(Path(path).read_bytes())
                except Exception: cur="MISSING"
                if cur!=pin:
                    drift.append({"evidence":eid,"artifact":path,"expected":pin,"actual":cur}); seen.add(path)
        for path,pin in (proof.get("artifact_hashes") or {}).items():
            if path in seen: continue
            try: cur=sha256_hex(Path(path).read_bytes())
            except Exception: cur="MISSING"
            if cur!=pin:
                drift.append({"evidence":"*","artifact":path,"expected":pin,"actual":cur})
        if drift:
            state["knowledge_status"]="STALE"
            state["knowledge_drift"]={"detected_at":now_iso(),"drift":drift}
            return {"status":"STALE","drift":drift}
        if state.get("knowledge_status")=="STALE":
            state["knowledge_status"]="VALID"   # мир снова бит-в-бит совпадает с наблюдённым
        return {"status":"VALID","drift":[]}

class EvidenceGraph:
    \"\"\"Граф claim/observation/artifact/verification.\"\"\"
""",
"SP-15 KnowledgeAuditor")

# ─── SP-16: runtime binding — write/read/verify несут состояние артефакта ───
splice(
"""                    state["ledger"].append({"step": step_idx, "action": act["name"],
                                            "ok": obs.ok, "kind": obs.kind,
                                            "obs_brief": obs.brief(280)})
""",
"""                    _row={"step": step_idx, "action": act["name"],
                          "ok": obs.ok, "kind": obs.kind,
                          "obs_brief": obs.brief(280)}
                    # v3.4.0 ArtifactEvidenceEdge: состояние артефакта В МОМЕНТ наблюдения —
                    # не только write, но и read (главный эпистемический источник) и verify.
                    if obs.ok and isinstance(obs.meta, dict) and obs.meta.get("path"):
                        _p=str(obs.meta["path"])
                        _h=obs.meta.get("sha256")
                        if _h is None:
                            try: _h=sha256_hex(Path(_p).read_bytes())
                            except Exception: _h=None
                        if _h is not None:
                            _row["artifact_path"]=_p; _row["artifact_sha256"]=str(_h)
                    state["ledger"].append(_row)
""",
"SP-16 runtime artifact binding")

# ─── SP-17: run-loop — аудит закреплённого знания каждый такт ───────────────
splice(
"""        while len(state["ledger"]) < self.cfg.max_steps:
            if time.monotonic() - started > self.cfg.time_budget_s:
""",
"""        while len(state["ledger"]) < self.cfg.max_steps:
            if state.get("commit"):
                KnowledgeAuditor.audit(state)   # v3.4.0 N-DRIFT: сверка закреплённого знания с миром
            if time.monotonic() - started > self.cfg.time_budget_s:
""",
"SP-17 run-loop audit wiring")

# ─── SP-18: перенумерация подменённых тестов T67–T72 → T82–T87, дубль T73 → T81 ──
splice('    check("T67 proof closure dangling", t_proof_closure_rejects_dangling_input)',
       '    check("T82 proof closure dangling", t_proof_closure_rejects_dangling_input)', "SP-18a")
splice('    check("T68 proof closure closed", t_proof_closure_accepts_closed_graph)',
       '    check("T83 proof closure closed", t_proof_closure_accepts_closed_graph)', "SP-18b")
splice('    check("T69 temporal future", t_temporal_future_proof_rejected)',
       '    check("T84 temporal future", t_temporal_future_proof_rejected)', "SP-18c")
splice('    check("T70 proof closure cycle", t_proof_closure_rejects_cycle)',
       '    check("T85 proof closure cycle", t_proof_closure_rejects_cycle)', "SP-18d")
splice('    check("T71 falsification contested", t_falsification_blocks_contested)',
       '    check("T86 falsification contested", t_falsification_blocks_contested)', "SP-18e")
splice('    check("T72 temporal future evidence", t_temporal_rejects_future_evidence)',
       '    check("T87 temporal future evidence", t_temporal_rejects_future_evidence)', "SP-18f")
splice('    check("T73 CAS changed state", t_cas_rejects_changed_state)',
       '    check("T81 CAS changed state", t_cas_rejects_changed_state)', "SP-18g")

print("Часть 2 сплайсов применена.")
Path("/home/z/my-project/scripts/_v340_stage2.py").write_text(src, encoding="utf-8")
print("Стадия 2 сохранена: scripts/_v340_stage2.py")
